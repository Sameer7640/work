=== Fancy Product Designer (radykal) ===
Contributors: radykal alias Rafael Dery


== Installation ==

Simply drop the fancy-product-designer folder into your wp-content/plugins folder.


== Information ==

If you need any help with the plugin or searching for the documentation, please visit:

http://support.fancyproductdesigner.com


Thanks!
Rafael
