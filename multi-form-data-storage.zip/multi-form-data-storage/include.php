<?php

/******************************************************************************/
/******************************************************************************/

require_once('define.php');

/******************************************************************************/

require_once(PLUGIN_MFDS_CLASS_PATH.'MFDS.File.class.php');
require_once(PLUGIN_MFDS_CLASS_PATH.'MFDS.Include.class.php');
require_once(PLUGIN_MFDS_CLASS_PATH.'MFDS.Extension.class.php');

MFDSInclude::includeFileFromDir(PLUGIN_MFDS_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/