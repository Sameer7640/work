<?php
	woodmart_search_form( array(
		'ajax' => false,
		'post_type' => 'post'
	) );
?>