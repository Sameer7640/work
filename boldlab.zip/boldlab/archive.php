<?php

get_header();

// Include content template
boldlab_template_part( 'content', 'templates/content', 'blog' );

get_footer();