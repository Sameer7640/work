<?php if ( $params === 'masonry' ) { ?>
	<div class="qodef-grid-masonry-sizer"></div>
	<div class="qodef-grid-masonry-gutter"></div>
<?php } ?>