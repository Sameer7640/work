<?php

// Include mobile logo
boldlab_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
boldlab_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
boldlab_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );