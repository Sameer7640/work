<?php

include_once BOLDLAB_INC_ROOT_DIR . '/search/helper.php';