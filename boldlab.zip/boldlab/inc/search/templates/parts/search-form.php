<div class="qodef-e-search-heading">
	<h3 class="qodef-e-search-heading-title"><?php esc_html_e( 'New search:', 'boldlab' ); ?></h3>
	<div class="qodef-e-search-heading-form">
		<?php get_search_form(); ?>
	</div>
</div>