<?php

include_once BOLDLAB_INC_ROOT_DIR . '/plugins/class-tgm-plugin-activation.php';
include_once BOLDLAB_INC_ROOT_DIR . '/plugins/plugins-activation.php';