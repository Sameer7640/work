<?php
/*
Template Name: Full Width Template
*/

get_header();

// Include content template
boldlab_template_part( 'content', 'templates/content' );

get_footer();