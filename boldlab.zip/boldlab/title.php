<?php

// Hook to include page title template
do_action( 'boldlab_action_page_title_template' );