<?php

define( 'BOLDLAB_ROOT', get_template_directory_uri() );
define( 'BOLDLAB_ROOT_DIR', get_template_directory() );
define( 'BOLDLAB_ASSETS_ROOT', BOLDLAB_ROOT . '/assets' );
define( 'BOLDLAB_ASSETS_ROOT_DIR', BOLDLAB_ROOT_DIR . '/assets' );
define( 'BOLDLAB_ASSETS_CSS_ROOT', BOLDLAB_ASSETS_ROOT . '/css' );
define( 'BOLDLAB_ASSETS_CSS_ROOT_DIR', BOLDLAB_ASSETS_ROOT_DIR . '/css' );
define( 'BOLDLAB_ASSETS_JS_ROOT', BOLDLAB_ASSETS_ROOT . '/js' );
define( 'BOLDLAB_ASSETS_JS_ROOT_DIR', BOLDLAB_ASSETS_ROOT_DIR . '/js' );
define( 'BOLDLAB_INC_ROOT', BOLDLAB_ROOT . '/inc' );
define( 'BOLDLAB_INC_ROOT_DIR', BOLDLAB_ROOT_DIR . '/inc' );
