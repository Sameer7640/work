<?php
/**
 * Index Template
 *
 * @package WP Pro Real Estate 7
 * @subpackage Template
 */

get_header(); 

	get_template_part('archive');

get_footer(); ?>