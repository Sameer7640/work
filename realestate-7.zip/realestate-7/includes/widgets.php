<?php

	include( get_template_directory() . '/includes/widgets/ct-widget-tabs.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-adspace.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-agentinfo.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-agentsotherlistings.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-blogauthor.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-brokerinfo.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-search.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-latestposts.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-listingbooktour.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-listings.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-listingscrolltocontact.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-listingssearch.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-listingssocial.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-contactinfo.php');
	include( get_template_directory() . '/includes/widgets/ct-widget-testimonials.php');

?>