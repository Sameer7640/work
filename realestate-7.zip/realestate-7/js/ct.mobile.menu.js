/**
 * CT Mobile Menu
 *
 * @package WP Pro Real Estate 7
 * @subpackage JavaScript
 */

jQuery(function($){
	$(document).ready(function(){

		$('#masthead .sub-menu li a').before('<i class="fas fa-angle-right"></i>');

		$('.mobile-nav ul').removeClass('cbp-tm-menu');
		$('.mobile-nav ul').addClass('cbp-spmenu');
		
		$('<div id="showLeftPush" class="show-hide"><i id="showLeftPushIcon" class="fa fa-navicon"></i></div>', {
		}).appendTo("#masthead");		

		var menuLeft = document.getElementById( 'cbp-spmenu' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			showLeftPushIcon = document.getElementById( 'showLeftPushIcon' ),
			body = document.body;
			container = document.getElementById( 'wrapper' ),

		showLeftPush.onclick = function() {
			$('body').bind('touchmove', function(e){e.preventDefault()})
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toleft' );
			classie.toggle( body, 'stop-scrolling' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			classie.toggle( showLeftPushIcon, 'fa-close' );
		};

		if(!$("body").hasClass("stop-scrolling")) {
			$('body').unbind('touchmove')
		};
	
	});
});