<?php
/* Custom functions code goes here. */

/* Enqueue script and styles for child theme */
// add_action('wp_enqueue_scripts', 'enqueue_scripts_cs');
// function enqueue_scripts_cs() {
//   wp_enqueue_style( 'form-styles', get_stylesheet_directory_uri() . '/form/custom/css/forms-styles.css', false, '1.0.0', 'all' );
// }

// SHORTCODE TO ADD A FILE IN A PAGE
function cs_template_shortcode_wp($atts)
{
  $atts = shortcode_atts(array(
    'page' => ''
  ), $atts);
  ob_start();
  get_template_part($atts['page']);
  return ob_get_clean();
}
add_shortcode('cs-template-name', 'cs_template_shortcode_wp');


add_action('wp_head', 'myoverride', 1);
function myoverride()
{
  if (class_exists('Vc_Manager')) {
    remove_action('wp_head', array(visual_composer(), 'addMetaData'));
  }
}

include 'form/custom/functions.php';