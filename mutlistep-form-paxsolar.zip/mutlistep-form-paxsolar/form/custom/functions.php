<?php
require 'ajax.php';

define('CS_PATH', dirname(dirname(__FILE__)));
define('CS_URL', get_stylesheet_directory_uri());

add_action('wp_enqueue_scripts', 'enqueue_scripts_cs');
function enqueue_scripts_cs()
{
	wp_enqueue_style('form-styles', CS_URL . '/form/custom/css/forms-styles.css', false, false, 'all');
	wp_enqueue_script('validate', CS_URL . '/form/custom/js/jquery.validate.min.js', array('jquery'), false, true);
	wp_enqueue_script('loadingoverlay', CS_URL . '/form/custom/js/loadingoverlay.min.js', array('jquery'), false, true);
	wp_enqueue_script('sweetalert', CS_URL . '/form/custom/js/sweetalert.min.js', array('jquery'), false, true);
	wp_enqueue_script('customjs', CS_URL . '/form/custom/js/custom.js', array('jquery'), false, true);
	wp_localize_script(
		'customjs',
		'cs_object',
		array(
			'ajax_url' => admin_url('admin-ajax.php'),
		)
	);
}
