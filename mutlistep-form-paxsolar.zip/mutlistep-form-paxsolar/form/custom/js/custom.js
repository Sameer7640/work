jQuery(function ($) {
	// jQuery("#step-form").validate();

	jQuery.LoadingOverlaySetup({
		imageColor: "#8CC739"
	});

	jQuery(document).on('click', '.back-btn', function (event) {
		event.preventDefault();
		var step = jQuery(this).data('step');
		jQuery.LoadingOverlay("show");
		jQuery.ajax({
			type: 'post',
			url: cs_object.ajax_url + '?action=back_btn',
			dataType: 'json',
			data: { 'step': step },
		})
			.done(function (value) {
				jQuery.LoadingOverlay("hide");
				jQuery("#ajax-content").html(value.html);
			});
	});
	//back btn

	jQuery(document).on('submit', '#step-form', function (event) {
		event.preventDefault();
		jQuery.LoadingOverlay("show");
		var form = jQuery(this);
		var formData = new FormData(form[0]);
		jQuery.ajax({
			type: 'post',
			url: cs_object.ajax_url + '?action=steps',
			contentType: false,
			processData: false,
			dataType: 'json',
			data: formData,
		})
			.done(function (value) {
				jQuery.LoadingOverlay("hide");
				if (value.step < 6) {
					jQuery("#ajax-content").html(value.html);
				} else if (value.step == 6) {
					Swal.fire({ icon: 'success', title: 'ANFRAGE GESENDET!', text: 'Wir melden uns in Kürze bei Ihnen.' });
					setTimeout(() => {
						window.location.href = 'http://paxsolar.staging1.de/konfigurator/';
					}, 3000)
				}
			});
	});
	jQuery(document).on('change', '.multi-step-form .form-fields .radio-group input[type=radio]', function (event) {
		jQuery('#step-form').submit();
	});
	//steps
	// jQuery(document).on('change', '.file-upload-wrapper input[type=file]', function () {
	// 	if ((this.files[0].size) <= 2208588) {
	// 		console.log('File Uploaded!')
	// 	} else {
	// 		alert('File size should be less than 2mb!');
	// 		jQuery(this).val('')
	// 	}
	// });

	var _validFilejpeg = [".jpeg", ".jpg", ".bmp", ".pdf"];

	function validateForSize(oInput, minSize, maxSizejpeg) {
		//if there is a need of specifying any other type, just add that particular type in var  _validFilejpeg
		if (oInput.type == "file") {
			var sFileName = oInput.value;
			if (sFileName.length > 0) {
				var blnValid = false;
				for (var j = 0; j < _validFilejpeg.length; j++) {
					var sCurExtension = _validFilejpeg[j];
					if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length)
						.toLowerCase() == sCurExtension.toLowerCase()) {
						blnValid = true;
						break;
					}
				}

				if (!blnValid) {
					alert("Sorry, this file is invalid, allowed extension is: " + _validFilejpeg.join(", "));
					oInput.value = "";
					return false;
				}
			}
		}

		fileSizeValidatejpeg(oInput, minSize, maxSizejpeg);
	}

	function fileSizeValidatejpeg(fdata, minSize, maxSizejpeg) {
		if (fdata.files && fdata.files[0]) {
			var fsize = fdata.files[0].size / 1024; //The files property of an input element returns a FileList. fdata is an input element,fdata.files[0] returns a File object at the index 0.
			//alert(fsize)
			if (fsize > maxSizejpeg || fsize < minSize) {
				alert('This file size is: ' + fsize.toFixed(2) +
					"KB. Files should be in " + (minSize) + " to " + (maxSizejpeg) + " KB ");
				fdata.value = ""; //so that the file name is not displayed on the side of the choose file button
				return false;
			} else {
				console.log("");
			}
		}
	}
});