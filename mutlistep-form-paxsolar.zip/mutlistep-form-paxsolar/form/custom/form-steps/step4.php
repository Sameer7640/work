<form id="step-form" class="inner-wrap step4">
	<div class="progress-bar">
		<ul>
			<li><span>01</span></li>
			<li><span>02</span></li>
			<li><span>03</span></li>
			<li class="active"><span>04</span></li>
			<li><span>05</span></li>
			<li><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Angaben zum geplanten Projekt
			</h3>
		</div>
		<div class="d-flex justify-content-center align-items-center flex-wrap">
			<div class="form-group col-md-6">
				<label for="alter_des_daches">
					<span>Alter des Daches?*</span>
				</label>
				<select name="">
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="neu">neu</option>
					<option value="1-5 Jahre">1-5 Jahre</option>
					<option value="5-10 Jahre">5-10 Jahre</option>
					<option value="über 10 Jahre">über 10 Jahre</option>
				</select>
				
			</div>
			<div class="form-group col-md-6">
				<label for="wie_viele_dachseiten_möchten_sie_belegen">
					<span>Wie viele Dachseiten möchten Sie belegen?*</span>
				</label>
				<select id="wie_viele_dachseiten_möchten_sie_belegen" name="wie_viele_dachseiten_möchten_sie_belegen" required>
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
				</select>
			</div>
			<div class="form-group col-md-6">
				<label for="welche_eindeckung_hat_ihr_dach">
					<span>Welche Eindeckung hat Ihr Dach?*</span>
				</label>
				<select id="welche_eindeckung_hat_ihr_dach" name="welche_eindeckung_hat_ihr_dach" required>
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="bitumen">Bitumen</option>
					<option value="folie">Folie</option>
					<option value="pfannen zieger">Pfannen / Zieger</option>
					<option value="Trapezblech">Trapezblech</option>
				</select>
			</div>
			<div class="form-group col-md-6">
				<label for="in_welche_himmelsrichtung_ihr_haus_ausgerichtet">
					<span>In welche Himmelsrichtung Ihr Haus ausgerichtet?*</span>
				</label>
				<select id="in_welche_himmelsrichtung_ihr_haus_ausgerichtet" name="in_welche_himmelsrichtung_ihr_haus_ausgerichtet" required>
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="nord">Nord</option>
					<option value="nordost">Nordost</option>
					<option value="osten">Ost</option>
					<option value="suedost">Südost</option>
					<option value="sued">Süd</option>
					<option value="suedwest">Südwest</option>
					<option value="west">West</option>
					<option value="nordwest">Nordwest</option>
					<option value="ostwest">Ostwest</option>
				</select>
			</div>
			<div class="form-group col-md-6">
				<label for="belegbare_flaeche">
					<span>Belegbare Fläche(m²)* </span>
				</label>
				<input type="text" id="belegbare_flaeche" name="belegbare_flaeche" required>
			</div>
			<div class="form-group col-md-6">
				<label>
					<span>Sind kleinere Verschattungen vorhanden?*</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="sind_kleinere_verschattungen_vorhanden" value="Ja" class="me-2" required>
					<span>Ja</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="sind_kleinere_verschattungen_vorhanden" value="Nein" class="me-2" required>
					<span>Nein</span>
				</label>
			</div>
			<div class="form-group col-md-6">
				<label for="wie_stark_ist_die_neigung_ihres_hausdachs">
					<span>Wie stark ist die Neigung Ihres Hausdachs?*</span>
				</label>
				<select id="wie_stark_ist_die_neigung_ihres_hausdachs" name="wie_stark_ist_die_neigung_ihres_hausdachs" required>
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="weniger als 10">weniger als 10 °</option>
					<option value="10 bis 25">10 bis 25 °</option>
					<option value="groesser als 30">größer als 30 °</option>
					<option value="ich weiß nicht">ich weiß nicht</option>
				</select>
			</div>
			<div class="form-group col-md-6">
				<label>
					<span>Ist eine Wärmepumpe vorhanden?*</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="ist_eine_wärmepumpe_vorhanden" value="Ja" required>
					<span>Ja</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="ist_eine_wärmepumpe_vorhanden" value="Nein" required>
					<span>Nein</span>
				</label>
			</div>
		</div>
		<div class="form-group col-12 d-flex justify-content-between mt-4">
			<button type="button" class="back-btn" data-step="3">SCHRITT ZURÜCK</button>
			<input type="submit" value="Nächster Schritt">
		</div>
	</div>
	<input type="hidden" name="step" value="4">
</form>