<form id="step-form" class="inner-wrap step5" enctype="multipart/form-data">
	<div class="progress-bar">
		<ul>
			<li><span>01</span></li>
			<li><span>02</span></li>
			<li><span>03</span></li>
			<li><span>04</span></li>
			<li class="active"><span>05</span></li>
			<li><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Angaben zum geplanten Projekt
			</h3>
		</div>
		<div class="d-flex align-items-center flex-wrap">
			<div class="form-group col-md-6">
				<label>
					<span>Wird in Ihrem Haushalt ein E-Auto genutzt und geladen?*</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="wird_in_ihrem_haushalt_ein_e_auto_genutzt_und_geladen" value="Ja" required>
					<span>Ja</span>
				</label>
				<label class="radio-inline d-inline-flex align-items-center me-2">
					<input type="radio" name="wird_in_ihrem_haushalt_ein_e_auto_genutzt_und_geladen" value="Nein" required>
					<span>Nein</span>
				</label>
			</div>
			<div class="form-group col-md-6">
				<label for="wer_ist_ihr_energieversorger_netzbetreiber">
					<span>Wer ist Ihr Energieversorger / Netzbetreiber?*</span>
				</label>
				<input type="text" id="wer_ist_ihr_energieversorger_netzbetreiber" name="wer_ist_ihr_energieversorger_netzbetreiber" required>
			</div>
			<div class="form-group col-md-6">
				<label for="wie_hoch_ist_der_jahresstromverbrauch_ihres_haushalts">
					<span>Wie hoch ist der Jahresstromverbrauch Ihres Haushalts?*</span>
				</label>
				<select id="wie_hoch_ist_der_jahresstromverbrauch_ihres_haushalts" name="wie_hoch_ist_der_jahresstromverbrauch_ihres_haushalts" required>
					<option value="bitte auswählen" disabled selected readonly>bitte auswählen</option>
					<option value="weniger als 2.500 kWh">weniger als 2.500 kWh</option>
					<option value="2.500 – 5.000 kWh">2.500 – 5.000 kWh</option>
					<option value="mehr als 5000 kWh">mehr als 5000 kWh</option>
					<option value="ich weiß nicht">ich weiß nicht</option>
				</select>
			</div>
			<div class="form-group col-md-12">
				<label>
					<span>Grundriss vom Dach (Fotos hochladen)</span>
				</label>
				<!-- <label class="file-upload-wrapper">
					<svg width="50" height="50" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
						<path stroke-linecap="round" stroke-linejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
					</svg>
					<input type="file" name="grundriss_vom_dach_fotos_hochladen" accept="image/*,video/*,.pdf,.csv,.zip">
				</label> -->
				<div class="filepond-wrapper">
					<input type="file" class="filepond">
				</div>
			</div>
		</div>
		<div class=" form-group col-12 d-flex justify-content-between mt-4">
			<button type="button" class="back-btn" data-step="4">SCHRITT ZURÜCK</button>
			<input type="submit" value="Nächster Schritt">
		</div>
	</div>
	<input type="hidden" name="step" value="5">
</form>
<script>
	jQuery(function($) {
		FilePond.registerPlugin(FilePondPluginFileValidateSize);
		FilePond.registerPlugin(FilePondPluginFileValidateType);

		// Get a reference to the file input element
		const inputElement = document.querySelector('input[type="file"].filepond');

		// Create a FilePond instance
		const pond = FilePond.create(inputElement, {
			name: 'grundriss_vom_dach_fotos_hochladen[]',
			storeAsFile: true,
			allowMultiple: true,
			maxFiles: 5,
			maxFileSize: '10MB',
			allowFileTypeValidation: true,
			acceptedFileTypes: ['image/png', 'image/jpeg', 'image/jpg', 'pdf/jpeg', 'application/pdf'],
			credits: false,
			labelIdle: 'JPEG, JPG, PNG oder PDF bis zu 10 MB je Datei <span class="filepond--label-action"> durchsuchen </span>'
		});
	})
</script>