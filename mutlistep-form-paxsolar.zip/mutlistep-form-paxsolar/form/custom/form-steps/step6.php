<form id="step-form" class="inner-wrap step6">
	<div class="progress-bar">
		<ul>
			<li><span>01</span></li>
			<li><span>02</span></li>
			<li><span>03</span></li>
			<li><span>04</span></li>
			<li><span>05</span></li>
			<li class="active"><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Angaben zum geplanten Projekt
			</h3>
		</div>
		<div class="d-flex align-items-center flex-wrap">
			<div class="form-group col-md-6">
				<label for="vor_und_nachname">
					<span>Vor- und Nachname*</span>
				</label>
				<input type="text" id="vor_und_nachname" name="vor_und_nachname" required>
			</div>
			<div class="form-group col-md-6">
				<label for="Firma">
					<span>Firma</span>
				</label>
				<input type="text" id="Firma" name="Firma">
			</div>
			<div class="form-group col-md-6">
				<label for="E-Mail">
					<span>E-Mail*</span>
				</label>
				<input type="email" id="E-Mail"  name="E-Mail" required>
			</div>
			<div class="form-group col-md-6">
				<label for="Telefon">
					<span>Telefon</span>
				</label>
				<input type="tel" id="Telefon" name="Telefon">
			</div>
			<div class="form-group col-12">
				<label for="Postleitzahl">
					<span>Ihre Nachricht</span>
				</label>
				<textarea name="ihre_nachricht" cols="30" rows="10"></textarea>
			</div>
			<div class="form-group col-md-12">
				<div class="d-flex align-items-start gap-2 acceptance-wrap">
					<input type="checkbox" id="Datenschutzerklärung" name="Datenschutzerklärung" required>
					<span class="cs-checkbox"></span>
					<label for="Datenschutzerklärung" class="fw-normal">
						<small>Ich habe die <a href="/datenschutzerklaerung">Datenschutzerklärung</a> gelesen. Ich stimme zu, dass meine Angaben zur Kontaktaufnahme und für Rückfragen dauerhaft gespeichert werden.</small>
					</label>
				</div>
			</div>
		</div>
		<div class="form-group col-12 d-flex justify-content-between mt-4">
			<button type="button" class="back-btn" data-step="5">SCHRITT ZURÜCK</button>
			<input type="submit" value="Senden">
		</div>
	</div>
	<input type="hidden" name="step" value="6">
</form>