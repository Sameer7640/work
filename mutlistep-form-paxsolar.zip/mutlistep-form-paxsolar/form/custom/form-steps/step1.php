<form id="step-form" class="inner-wrap step1">
	<div class="progress-bar">
		<ul>
			<li class="active"><span>01</span></li>
			<li><span>02</span></li>
			<li><span>03</span></li>
			<li><span>04</span></li>
			<li><span>05</span></li>
			<li><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Wo möchten Sie die Photovoltaik-Anlage verwenden?
			</h3>
		</div>
		<div class="d-flex justify-content-center flex-wrap">
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="wo_möchten_sie_die_photovoltaik_anlage_verwenden" value="Privat" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Privat.svg">
					<span class="radio-text">Privat</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="wo_möchten_sie_die_photovoltaik_anlage_verwenden" value="Gewerblich" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Gewerblich.svg">
					<span class="radio-text">Gewerblich</span>
				</label>
			</div>
		</div>
		<!-- <div class="form-group full">
			<input type="submit" value="Nächster Schritt">
		</div> -->
	</div>
	<input type="hidden" name="step" value="1">
</form>