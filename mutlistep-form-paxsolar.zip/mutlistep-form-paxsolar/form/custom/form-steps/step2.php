<form id="step-form" class="inner-wrap step2">
	<div class="progress-bar">
		<ul>
			<li><span>01</span></li>
			<li class="active"><span>02</span></li>
			<li><span>03</span></li>
			<li><span>04</span></li>
			<li><span>05</span></li>
			<li><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Bitte wählen Sie den gewünschten Typ Ihrer Photovoltaikanlage:
			</h3>
		</div>
		<div class="d-flex justify-content-center flex-wrap">
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="bitte_wählen_sie_den_gewünschten_typ_ihrer_photovoltaikanlage" value="Photovoltaikanlage ohne Speicher" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/PA-Ohne.svg">
					<span class="radio-text">Photovoltaikanlage ohne Speicher</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="bitte_wählen_sie_den_gewünschten_typ_ihrer_photovoltaikanlage" value="Photovoltaikanlage mit Speicher" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/PA-Speicher.svg">
					<span class="radio-text">Photovoltaikanlage mit Speicher</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="bitte_wählen_sie_den_gewünschten_typ_ihrer_photovoltaikanlage" value="Photovoltaikanlage mit Speicher und Wallbox" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/PA-Speicher-WA.svg">
					<span class="radio-text">Photovoltaikanlage mit Speicher + Wallbox</span>
				</label>
			</div>
		</div>
		<div class="form-group col-12 d-flex justify-content-between mt-4">
			<button type="button" class="back-btn" data-step="1">SCHRITT ZURÜCK</button>
			<input type="submit" value="Nächster Schritt">
		</div>
	</div>
	<input type="hidden" name="step" value="2">
</form>