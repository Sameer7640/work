<form id="step-form" class="inner-wrap step3">
	<div class="progress-bar">
		<ul>
			<li><span>01</span></li>
			<li><span>02</span></li>
			<li class="active"><span>03</span></li>
			<li><span>04</span></li>
			<li><span>05</span></li>
			<li><span>06</span></li>
		</ul>
	</div>
	<div class="form-fields">
		<div class="form-fields-header">
			<h3 class="step-heading">
				Welche Form hat Ihr Dach?
			</h3>
		</div>
		<div class="d-flex justify-content-center flex-wrap">
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="welche_form_hat_ihr_dach" value="Flachdach" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Flachdach.svg">
					<span class="radio-text">Flachdach</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="welche_form_hat_ihr_dach" value="Pultdach" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Pultdach.svg">
					<span class="radio-text">Pultdach</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="welche_form_hat_ihr_dach" value="Satteldach" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Satteldach.svg">
					<span class="radio-text">Satteldach</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="welche_form_hat_ihr_dach" value="Walmdach" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Walmdach.svg">
					<span class="radio-text">Walmdach</span>
				</label>
			</div>
			<div class="form-group col-12 col-sm-6 col-md-4 radio-group">
				<label>
					<input type="radio" name="welche_form_hat_ihr_dach" value="Zeltdach" required>
					<span class="selection-indicator"></span>
					<img src="http://paxsolar.staging1.de/wp-content/uploads/2022/10/Zeltdach.svg">
					<span class="radio-text">Zeltdach</span>
				</label>
			</div>
		</div>
		<div class="form-group col-12 d-flex justify-content-between mt-4">
			<button type="button" class="back-btn" data-step="2">SCHRITT ZURÜCK</button>
			<input type="submit" value="Nächster Schritt">
		</div>
	</div>
	<input type="hidden" name="step" value="3">
</form>