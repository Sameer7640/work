<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class cs_ajax
{
    function __construct()
    {
        add_action("wp_ajax_steps", array($this, 'steps'), 10);
        add_action("wp_ajax_nopriv_steps", array($this, 'steps'), 10);

        add_action("wp_ajax_back_btn", array($this, 'back_btn'), 10);
        add_action("wp_ajax_nopriv_back_btn", array($this, 'back_btn'), 10);
    }

    function steps()
    {
        ob_start();
        session_start();
        if ($_POST["step"] == 1) {
            $_SESSION['step1'] = $_POST;
            unset($_SESSION['step1']['step']);
            require CS_PATH . '/custom/form-steps/step2.php';
            $html = ob_get_clean();
            $ajax['step'] = 1;
            $ajax['status'] = true;
            $ajax['html'] = $html;
        } elseif ($_POST["step"] == 2) {
            $_SESSION['step2'] = $_POST;
            unset($_SESSION['step2']['step']);
            require CS_PATH . '/custom/form-steps/step3.php';
            $html = ob_get_clean();
            $ajax['step'] = 2;
            $ajax['status'] = true;
            $ajax['html'] = $html;
        } elseif ($_POST["step"] == 3) {
            $_SESSION['step3'] = $_POST;
            unset($_SESSION['step3']['step']);
            require CS_PATH . '/custom/form-steps/step4.php';
            $html = ob_get_clean();
            $ajax['step'] = 3;
            $ajax['status'] = true;
            $ajax['html'] = $html;
        } elseif ($_POST["step"] == 4) {
            $_SESSION['step4'] = $_POST;
            unset($_SESSION['step4']['step']);
            require CS_PATH . '/custom/form-steps/step5.php';
            $html = ob_get_clean();
            $ajax['step'] = 4;
            $ajax['status'] = true;
            $ajax['html'] = $html;
        } elseif ($_POST["step"] == 5) {
            $_SESSION['step5'] = $_POST;
            unset($_SESSION['step5']['step']);
            
            // $target_dir = CS_PATH . '/custom/files/';
            $total = count($_FILES['grundriss_vom_dach_fotos_hochladen']['name']);

            // $target_file = $target_dir . basename($_FILES["grundriss_vom_dach_fotos_hochladen"]["name"]);
            
            for ($i = 0; $i < $total; $i++) {
                //Get the temp file path
                $tmpFilePath = $_FILES['grundriss_vom_dach_fotos_hochladen']['tmp_name'][$i];

                //Make sure we have a file path
                if ($tmpFilePath != "") {
                    //Setup our new file path
                    $newFilePath = CS_PATH . '/custom/files/' . $_FILES['grundriss_vom_dach_fotos_hochladen']['name'][$i];

                    //Upload the file into the temp dir
                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {

                        //Handle other code here

                    }
                }
            }


            if ($_FILES["grundriss_vom_dach_fotos_hochladen"]["type"] == 'image/jpg' || $_FILES["grundriss_vom_dach_fotos_hochladen"]["type"] == 'image/png' || $_FILES["grundriss_vom_dach_fotos_hochladen"]["type"] == 'image/jpeg') {
                move_uploaded_file($_FILES["grundriss_vom_dach_fotos_hochladen"]["tmp_name"], $target_file);
            }
            $_SESSION['step5_file'] = $_FILES["grundriss_vom_dach_fotos_hochladen"]["name"];
            require CS_PATH . '/custom/form-steps/step6.php';
            $html = ob_get_clean();
            $ajax['step'] = 5;
            $ajax['status'] = true;
            $ajax['html'] = $html;
        } elseif ($_POST["step"] == "6") {
            $_SESSION['step6'] = $_POST;
            unset($_SESSION['step6']['step']);
            $ajax['step'] = 6;
            $ajax['status'] = true;

            $message = '';
            $message .= '<html><body>';
            $message .= '<center><h3>PaxSolar Formulardaten</h3></center>';
            $message .= '<table rules="all" style="border-color:#666;width:100%" cellpadding="10">';
            foreach ($_SESSION['step1'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step2'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step3'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step4'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step5'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step6'] as $key => $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>" . ucwords(str_replace(array('_', '-'), ' ', $key)) . ":</strong> </td><td>" . $value . "</td></tr>";
                endif;
            }
            foreach ($_SESSION['step5_file'] as $value) {
                if (!empty($value)) :
                    $message .= "<tr style='background: #eee;'><td><strong>Attachment:</strong> </td><td><a href='http://paxsolar.staging1.de/wp-content/themes/Impreza-child/form/custom/files/" . $value . "'>Attachment Link</a></td></tr>";
                endif;
            }
            // $message .= "<tr style='background: #eee;'><td><strong>Attachment:</strong> </td><td><a href='http://paxsolar.staging1.de/wp-content/themes/Impreza-child/form/custom/files/" . $_SESSION['step5_file'] . "'>Attachment Link</a></td></tr>";
            $message .= "</table>";
            $message .= "</body></html>";

            $headers = array('Content-Type: text/html; charset=UTF-8');
            $to = 'angebot@pax-solar.de';
            $subject = "Neue Anfrage";
            wp_mail($to, $subject, $message, $headers);
            $ajax['msg'] = 'Thank you for the details we will contact you to discuss your quote in further detail';
            session_destroy();
        }
        print(json_encode($ajax));
        exit();
    }

    function back_btn()
    {
        ob_start();
        if ($_POST['step'] == '1') {
            require CS_PATH . '/custom/form-steps/step1.php';
        } elseif ($_POST['step'] == '2') {
            require CS_PATH . '/custom/form-steps/step2.php';
        } elseif ($_POST['step'] == '3') {
            require CS_PATH . '/custom/form-steps/step3.php';
        } elseif ($_POST['step'] == '4') {
            require CS_PATH . '/custom/form-steps/step4.php';
        } elseif ($_POST['step'] == '5') {
            require CS_PATH . '/custom/form-steps/step5.php';
        } elseif ($_POST['step'] == '6') {
            require CS_PATH . '/custom/form-steps/step6.php';
        }

        $html = ob_get_clean();
        $ajax['status'] = true;
        $ajax['html'] = $html;
        print(json_encode($ajax));
        exit();
    }
}
new cs_ajax();
