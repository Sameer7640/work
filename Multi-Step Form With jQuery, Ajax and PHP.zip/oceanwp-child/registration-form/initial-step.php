<?php /* Template Name: Registration Form */ get_header(); ?>

<section class="reg-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row registration-form align-items-center">
                    <div class="col-md-4">
                        <div class="rf-side-image">
                            <img src="<?php echo site_url() . '/wp-content/uploads/2021/12/form-wizard-1.jpg'; ?>" alt="">
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="rf-form-wrapper">
                            <div class="rf-form-title text-center">
                                <h2>Registration</h2>
                            </div>
                            <div class="rf-form-progress-bar">
                                <ul class="rf-prograss-bar">
                                    <li>
                                        <a href="#" id="goToStep1" class="step-current">
                                            <span class="rf-dot"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" id="goToStep2" class="">
                                            <span class="rf-dot"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" id="goToStep3" class="">
                                            <span class="rf-dot"></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="rf-form">
                                <form action="" method="POST" id="registrationForm">
                                    <div class="step-field-wrapper">
                                        <div id="regStep1" class="active" data-step="1">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3>Please fill with your details</h3>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="text" name="first_name" id="firstName" placeholder="First Name">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="text" name="last_name" id="lasttName" placeholder="Last Name">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="email" name="email_address" id="emailAddress" placeholder="Your Email">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="tel" name="phone_number" id="phoneNumber" placeholder="Phone Number">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="text" name="age" id="age" placeholder="Age">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-radio">
                                                        <label><input type="radio" name="gender" value="male" checked> Male</label>
                                                        <label><input type="radio" name="gender" value="female"> Female</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="regStep2" class="hidden"  data-step="2">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3>Please fill with additional info</h3>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="rf-field">
                                                        <input type="text" name="physical_address" id="phyAddress" placeholder="Address" >
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="text" name="city_name" id="cityName" placeholder="City" >
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <input type="text" name="zip_code" id="zipCode" pattern="[0-9]{5}"  placeholder="Zip Code" >
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rf-field">
                                                        <select name="country" id="countryName">
                                                            <option disabled selected>Your Country</option>
                                                            <option value="Pakistan">Pakistan</option>
                                                            <option value="India">India</option>
                                                            <option value="Iran">Iran</option>
                                                            <option value="China">China</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6"></div>
                                            </div>
                                        </div>
                                        <div id="regStep3" class="hidden"  data-step="3">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3>Send an optional message</h3>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="rf-field">
                                                        <textarea name="your_message" cols="30" rows="10" placeholder="Your message here!"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="step-action-wrapper">
                                        <div class="action-buttons-group">
                                            <button type="button" id="prevStep" data-prev="0"><img src="<?php echo site_url() . '/wp-content/uploads/2021/12/arrow-left-solid.svg'; ?>"> <span>Backward</span></button>
                                            <button type="button" id="nextStep" data-next="1"><span>Forward</span> <img src="<?php echo site_url() . '/wp-content/uploads/2021/12/arrow-right-solid.svg'; ?>"></button>
                                            <button type="submit" id="submit"><span>Submit</span> <img src="<?php echo site_url() . '/wp-content/uploads/2021/12/check-solid.svg'; ?>"></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>