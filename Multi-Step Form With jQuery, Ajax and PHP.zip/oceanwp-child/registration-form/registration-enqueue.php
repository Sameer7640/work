<?php 

// Ajax Callback Functions
require 'registration.php';

// Enqueue Custom Style and Scripts
function x_register_custom_scripts()
{
    wp_enqueue_style( 'reg-style', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/registration.css', array('reg-bootstrap'), '1.0', 'all' );
    wp_enqueue_style( 'reg-bootstrap', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/bootstrap-grid.min.css', array(), '4.3.1', 'all' );
    wp_enqueue_script( 'reg-script', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/registration.js', array('jquery', 'reg-validation', 'reg-loadingOverlay', 'reg-sweetalert2'), '1.0', true );
    wp_enqueue_script( 'reg-validation', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/library/jquery.validate.min.js', array('jquery'), '1.17.0', true );
    wp_enqueue_script( 'reg-loadingOverlay', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/library/loadingoverlay.min.js', array('jquery'), '2.1.7', true );
    wp_enqueue_script( 'reg-sweetalert2', get_stylesheet_directory_uri() . '/registration-form/custom-scripts/library/sweetalert2.all.min.js', array('jquery'), '11.3.0', true );
    wp_localize_script('reg-script', 'cs_object',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'x_register_custom_scripts' );