jQuery(document).ready(function () {

    let totalSteps = 3;
    let nextStep = 0
    let currnetStep = 1;
    let prevStep = 0;

    hidePrev();
    hideSubmit();

    // To Next Step
    jQuery(document).on('click', '#nextStep', function (e) {

        e.preventDefault();

        if (jQuery(this).attr('data-next') == 1) {

            // nextStep = 1 + 1     => 2
            nextStep = currnetStep + 1;
            // prevStep = 2 - 1     => 1
            prevStep = nextStep - 1;

            jQuery('#goToStep1').removeClass('step-current');
            jQuery('#goToStep1').addClass('step-done');
            jQuery('#goToStep2').addClass('step-current');
            jQuery('#prevStep').fadeIn(500);

            jQuery(this).attr('data-next', nextStep);
            jQuery('#prevStep').attr('data-prev', prevStep);
            jQuery('#regStep1').hide();
            jQuery('#regStep2').fadeIn(1000);

            // currnetStep = 2
            currnetStep = nextStep;

        }
        else if (jQuery(this).attr('data-next') == 2) {

            // nextStep = 2 + 1     => 3
            nextStep = currnetStep + 1;
            // prevStep = 3 - 1     => 2
            prevStep = nextStep - 1;

            jQuery('#goToStep2').removeClass('step-current');
            jQuery('#goToStep2').addClass('step-done');
            jQuery('#goToStep3').addClass('step-current');

            jQuery(this).attr('data-next', nextStep);
            hideNext();
            jQuery('#prevStep').attr('data-prev', prevStep);
            jQuery('#regStep2').hide();
            jQuery('#regStep3').fadeIn(1000);

            // currnetStep = 3
            currnetStep = nextStep;
        }

    });

    // To Previous Step
    jQuery(document).on('click', '#prevStep', function (e) {

        e.preventDefault();

        if (jQuery(this).attr('data-prev') == 1) {

            // currnetStep = 2 - 1      => 1
            currnetStep = currnetStep - 1;
            // prevStep = 1 - 1         => 0
            prevStep = prevStep - 1;

            jQuery('#goToStep1').removeClass('step-done');
            jQuery('#goToStep1').addClass('step-current');
            jQuery('#goToStep2').removeClass('step-current');
            jQuery('#prevStep').hide();

            jQuery('#nextStep').attr('data-next', currnetStep);
            jQuery(this).attr('data-prev', prevStep);
            jQuery('#regStep2').hide();
            jQuery('#regStep1').fadeIn(1000);

        }
        else if (jQuery(this).attr('data-prev') == 2) {

            // currnetStep = 3 - 1      => 2
            currnetStep = currnetStep - 1;
            // prevStep = 2 - 1         => 1
            prevStep = prevStep - 1;

            jQuery('#goToStep2').removeClass('step-done');
            jQuery('#goToStep3').removeClass('step-current');
            jQuery('#goToStep2').addClass('step-current');

            jQuery('#nextStep').attr('data-next', currnetStep);
            hideSubmit();
            jQuery('#nextStep').fadeIn(500);
            jQuery(this).attr('data-prev', prevStep);
            jQuery('#regStep3').hide();
            jQuery('#regStep2').fadeIn(1000);
        }

    });

    // Form Submit AJAX
    jQuery(document).on('submit', 'form#registrationForm', function (e) {
        e.preventDefault();

        var name = jQuery('#firstName').val();
        var email = jQuery('#emailAddress').val();
        var age = jQuery('#age').val();
        var zipCode = jQuery('#zipCode').val();

        if (name.length == 0 || email.length == 0 || age.length == 0 || zipCode.length == 0) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'It looks like some field are empty!'
            });
        }
        else {

            jQuery('.rf-form-wrapper').LoadingOverlay("show");
            var form = jQuery(this);
            var formData = new FormData(form[0]);

            jQuery.ajax({
                type: 'post',
                url: cs_object.ajax_url + '?action=step_form',
                contentType: false,
                processData: false,
                dataType: 'json',
                data: formData,
            }).done(function (value) {

                form.trigger('reset');
                makeFormReset();
                jQuery('.rf-form-wrapper').LoadingOverlay("hide");

                if (value) {

                    Swal.fire({
                        icon: 'success',
                        title: 'Thank You!',
                        text: 'Form Submitted Successfully!'
                    });

                    console.log(value);
                }

            }).fail(function () {
                jQuery.LoadingOverlay("hide");
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                });
            });
        }

    });

    function hideNext() {

        if (jQuery('#nextStep').attr('data-next') == totalSteps) {

            jQuery('#nextStep').hide();
            jQuery('#submit').fadeIn(500);

        }
    }

    function hidePrev() {

        if (jQuery('#prevStep').attr('data-prev') == 0) {

            jQuery('#prevStep').hide();

        }
    }

    function hideSubmit() {

        if (jQuery('#nextStep').attr('data-next') < totalSteps) {

            jQuery('#submit').hide();

        }
    }

    function makeFormReset() {

        nextStep = 0
        currnetStep = 1;
        prevStep = 0;

        jQuery('#goToStep1').removeClass('step-done');
        jQuery('#goToStep2').removeClass('step-current step-done');
        jQuery('#goToStep3').removeClass('step-done step-current');
        jQuery('#goToStep1').addClass('step-current');

        jQuery('#nextStep').attr('data-next', 1);
        jQuery('#prevStep').attr('data-prev', 0);

        hideSubmit();
        hidePrev();

        jQuery('#regStep3').hide();
        jQuery('#regStep1').fadeIn(500);
        jQuery('#nextStep').fadeIn(500);

    }


});