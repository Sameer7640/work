<?php

    add_action( "wp_ajax_step_form", 'step_form');
    add_action( "wp_ajax_nopriv_step_form", 'step_form');

    function step_form()
    {
        $formData = array(
            'first_name'        => $_POST['first_name'],
            'last_name'         => $_POST['last_name'],
            'email_address'     => $_POST['email_address'],
            'phone_number'      => $_POST['email_address'],
            'age'               => $_POST['age'],
            'gender'            => $_POST['gender'],
            'physical_address'  => $_POST['physical_address'],
            'city_name'         => $_POST['city_name'],
            'zip_code'          => $_POST['zip_code'],
            'country'           => $_POST['country'],
            'your_message'      => $_POST['your_message']
        );

        // Use This Data Anywhere You Want
        echo json_encode($formData);
        exit();
    }