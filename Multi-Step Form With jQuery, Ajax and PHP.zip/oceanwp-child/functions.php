<?php

	// Require Registration Files
	require 'registration-form/registration-enqueue.php';

	 add_action( 'wp_enqueue_scripts', 'oceanwp_child_enqueue_styles' );
	 function oceanwp_child_enqueue_styles() {
 		  wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' ); 
 		  } 
 ?>