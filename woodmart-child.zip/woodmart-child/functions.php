<?php
/**
 * Enqueue script and styles for child theme
 */
function woodmart_child_enqueue_styles() {
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'woodmart-style' ), woodmart_get_theme_info( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'woodmart_child_enqueue_styles', 10010 );

// Add template form theme
function cs_template_shortcode_wp( $atts ) {
    $atts = shortcode_atts( array(
        'page' => ''
    ), $atts );
    ob_start();
    get_template_part($atts['page']);
    return ob_get_clean();
}
add_shortcode( 'cs-template-name','cs_template_shortcode_wp' );
// [cs-template-name page="template/post-insights"]




remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 30 );
