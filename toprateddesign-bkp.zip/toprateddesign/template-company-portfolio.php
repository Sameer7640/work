<?php

$taxonomy = 'project-cat';
$terms = get_terms(array(
    'taxonomy' => $taxonomy,
));
// PAGINATION CODE
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$mainarray = array(
    'post_type' => array('portfolio'),
    'post_status' => array('publish'),
    'orderby' => 'date',
    'order' => 'DESC',
    'posts_per_page' => 6,
    'paged'       => $paged,
);
$q = new WP_Query($mainarray);

?>


<div class="portfolio-container">
    <?php while ($q->have_posts()) : $q->the_post(); ?>
        <div class="portfolio-inner">
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <div class="company-logo">
                        <?php if (has_post_thumbnail()) :
                            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium', true);
                        ?>
                            <a href="#" class="open-profile"><img src="<?php echo $thumbnail[0]; ?>"></a>
                        <?php else : ?>
                            <img src="<?php echo site_url() . '//wp-content/uploads/2022/05/image-1-e1652461110820.jpg'; ?>">
                        <?php endif ?>

                    </div>
                </div>

                <div class="col-lg-6 col-md-8">
                    <div class="company-detail-wrapper">
                        <div class="company-title">
                            <h3><?php the_title(); ?></h4>
                        </div>
                        <div class="company-rating">
                            4.9 <small>(17 reviews)</small>
                        </div>
                        <div class="company-inner-texr">
                            <?php if (!empty(get_the_excerpt())) {
                                echo strip_tags(substr(get_the_excerpt(), 0, 200));
                            } else {
                                echo strip_tags(substr(get_the_content(), 0, 200));
                            } ?>
                        </div>
                        <div class="company-services">
                            <h4>Top Services</h4>
                            <?php
                            $companyservices = wp_get_post_terms(get_the_ID(), $taxonomy);

                            if (!empty($companyservices) && !is_wp_error($companyservices)) {
                                echo '<ul class="company-services-list">';
                                foreach ($companyservices as $term) {
                                    echo '<li>' . $term->name . '</li>'; // Displaying the term name
                                }
                                echo '</ul>';
                            }
                            ?>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-12 company-detail-container">
                    <div class="company-contact-info">
                        <div class="company-cta">
                            <div class="custom-btn-wrapper">
                                <a href="<?php the_field('website_url'); ?>" class="btn cstm-primary-btn cstm-primary-icon-btn" target="_blank">Visit Website</a>
                            </div>
                            <div class="custom-btn-wrapper">
                                <a href="<?php the_permalink(); ?>" class="btn cstm-primary-bordered-btn cstm-primary-icon-btn">Visit Portfolio</a>
                            </div>
                        </div>
                        <div class="company-about-info">
                            <ul class="about-info-list">
                                <li class="about-info-item company-location"><?php the_field('location'); ?></li>
                                <li class="about-info-item company-employees"><?php the_field('employees'); ?></li>
                                <li class="about-info-item company-salary-range"><?php the_field('salary_range'); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    <?php endwhile;
    wp_reset_postdata(); ?>
</div>