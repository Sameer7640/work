<?php
/***
    MAIN FILE ( wp-backend.php )
*/

/*** Session Start */
add_action('init', function(){
    if( !session_id() )
    {
        @session_start();
    }
});

/*** Post Type codes */
include_once 'classes/cs_post_types.php';

/*** Include Additional Scripts */
include_once 'classes/Class_WP_Scripts.php';
new Class_WP_Scripts();

/*** Include Ajax Class */
include_once 'classes/Class_WP_Ajax.php';
new Class_WP_Ajax();


/*** Include Shortcode Class */
include_once 'classes/Class_WP_Shortcode.php';
new Class_WP_Shortcode();

include_once 'classes/class_main.php';