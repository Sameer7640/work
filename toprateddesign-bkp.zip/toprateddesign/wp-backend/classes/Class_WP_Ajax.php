<?php

/**
 * Enqueue Additional Styles & Scripts
 */

// error_reporting(E_ALL);
// ini_set('display_errors', 1);

class Class_WP_Ajax
{

      public function __construct()
      {
            add_action('wp_ajax_company_register', array($this, 'company_register'), 10);
            add_action('wp_ajax_nopriv_company_register', array($this, 'company_register'), 10);

            add_action('wp_ajax_company_login', array($this, 'company_login'), 10);
            add_action('wp_ajax_nopriv_company_login', array($this, 'company_login'), 10);

            add_action('wp_ajax_forgot_password', array($this, 'forgot_password'), 10);
            add_action('wp_ajax_nopriv_forgot_password', array($this, 'forgot_password'), 10);

            add_action('wp_ajax_reset_password', array($this, 'reset_password'), 10);
            add_action('wp_ajax_nopriv_reset_password', array($this, 'reset_password'), 10);

            add_action('wp_ajax_save_company_profile_data', array($this, 'save_company_profile_data'), 10);

            add_action('wp_ajax_save_company_services', array($this, 'save_company_services'), 10);

            add_action('wp_ajax_save_company_business_address', array($this, 'save_company_business_address'), 10);

            add_action('wp_ajax_save_industry_focus', array($this, 'save_industry_focus'), 10);

            add_action('wp_ajax_invite_a_client_for_reviews', array($this, 'invite_a_client_for_reviews'), 10);

            add_action('wp_ajax_save_company_portfolio', array($this, 'save_company_portfolio'), 10);

            add_action('wp_ajax_save_company_faqs', array($this, 'save_company_faqs'), 10);

            add_action('wp_ajax_save_company_employees', array($this, 'save_company_employees'), 10);

            add_action('wp_ajax_update_account_details', array($this, 'update_account_details'), 10);

            add_action('wp_ajax_update_user_password', array($this, 'update_user_password'), 10);

            add_action('wp_ajax_company_form_prev', array($this, 'company_form_prev'), 10);

            add_action('wp_ajax_company_form_specific_step', array($this, 'company_form_specific_step'), 10);

            add_action('wp_ajax_project_sort', array($this, 'project_sort'), 10);
            add_action('wp_ajax_nopriv_project_sort', array($this, 'project_sort'), 10);
      }

      public function company_register()
      {
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $company_name = sanitize_text_field($_POST['company_name']);
            $email = sanitize_email($_POST['email']);
            $website = sanitize_url($_POST['website']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
                  wp_send_json_error(array('message' => 'All fields are required'), 400);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  wp_send_json_error(array('message' => 'Invalid Email'), 400);
            }

            if (email_exists($email)) {
                  wp_send_json_error(array('message' => 'Email already exists'), 400);
            }

            if ($password != $confirm_password) {
                  wp_send_json_error(array('message' => 'Password does not match'), 400);
            }

            global $wpdb;

            $table = 'company_temp_users';

            $unique_token = md5(uniqid(rand(), true));

            $data = array(
                  'first_name' => $first_name,
                  'last_name' => $last_name,
                  'company_name' => $company_name,
                  'email' => $email,
                  'website' => $website,
                  'password' => $password,
                  'token' => $unique_token,
            );

            $formats = array('%s', '%s', '%s', '%s', '%s', '%s');
            $wpdb->insert($table, $data, $formats);
            $user_id = $wpdb->insert_id;

            if ($user_id) {
                  $to = $email;
                  $headers = 'From: TopRatedWeb <info@topratedwebdesign.com>' . "\r\n";
                  $subject = 'TopRatedWeb | Your account has been created';
                  $message = 'Thank you for registering with TopRatedWeb. Your account is pending for approval.';
                  $message .= 'Please click on the link below to activate your account. ' . site_url() . '/login/?token=' . $unique_token;
                  wp_mail($to, $subject, $message, $headers);

                  $data = array(
                        'redirect' => site_url() . '/thank-you-for-registering',
                  );
                  wp_send_json_success($data, 200);
            } else {
                  wp_send_json_error(array('message' => 'Something went wrong'), 400);
            }
      }

      public function company_login()
      {
            $email = sanitize_email($_POST['email']);
            $password = $_POST['password'];

            if (empty($email) || empty($password)) {
                  wp_send_json_error(array('message' => 'All fields are required'), 400);
            }

            $user = wp_authenticate($email, $password);

            if (is_wp_error($user)) {

                  global $wpdb;
                  $table = 'company_temp_users';
                  $query = $wpdb->prepare("SELECT * FROM $table WHERE email = %s AND password = %s", $email, $password);
                  $result = $wpdb->get_row($query);

                  if ($result) {
                        wp_send_json_error(array(
                              'title' => 'Account Pending for Approval',
                              'message' => 'Your account is pending for approval. Please check your email for activation link'
                        ), 400);
                  }

                  wp_send_json_error(array('message' => 'Invalid Email or Password'), 400);
            }

            wp_set_current_user($user->ID, $user->user_login);
            wp_set_auth_cookie($user->ID);
            do_action('wp_login', $user->user_login);

            $data = array(
                  'message' => 'Login Successful',
                  'redirect' => site_url('create-company')
            );

            wp_send_json_success($data, 200);
      }

      public function forgot_password()
      {
            $email = sanitize_email($_POST['email']);

            if (empty($email)) {
                  wp_send_json_error(array('message' => 'Email is required'), 400);
            }

            if (!email_exists($email)) {
                  wp_send_json_error(array('message' => 'Email does not exist'), 400);
            }

            $token = md5(uniqid(rand(), true));
            update_user_meta(get_user_by('email', $email)->ID, 'reset_password_token', $token);

            $to = $email;
            $headers = 'From: TopRatedWeb <info@topratedwebdesign.com>' . "\r\n";
            $subject = 'TopRatedWeb | Reset Password';
            $message = 'Please click on the link below to reset your password. ' . site_url() . '/reset-password/?token=' . $token;
            wp_mail($to, $subject, $message, $headers);

            wp_send_json_success(array(
                  'message' => 'Reset Password Link Sent'
            ), 200);
      }

      public function reset_password()
      {
            $token = $_POST['token'];

            if (empty($token)) {
                  wp_send_json_error(array('message' => 'Invalid Token'), 400);
            }

            $users = get_users(array(
                  'meta_key' => 'reset_password_token',
                  'meta_value' => $token,
                  'number' => 1,
                  'count_total' => false,
            ));

            if (empty($users)) {
                  wp_send_json_error(array('message' => 'Invalid Token. Please try sending the reset password link again'), 400);
            }

            $user_id = $users[0]->ID;

            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if (empty($password) || empty($confirm_password)) {
                  wp_send_json_error(array('message' => 'All fields are required'), 400);
            }

            if ($password != $confirm_password) {
                  wp_send_json_error(array('message' => 'Password does not match'), 400);
            }

            wp_set_password($password, $user_id);
            delete_user_meta($user_id, 'reset_password_token');

            wp_send_json_success(array(
                  'message' => 'Password Reset Successful',
                  'redirect' => site_url('login')
            ), 200);
      }

      public function save_company_profile_data()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $company_profile = array(
                  'company_name' => sanitize_text_field($_POST['company_name']),
                  'year_found' => sanitize_text_field($_POST['year_found']),
                  'tag_line' => sanitize_text_field($_POST['tag_line']),
                  'email' => sanitize_email($_POST['email']),
                  'min_project_amount' => sanitize_text_field($_POST['min_project_amount']),
                  'website' => sanitize_url($_POST['website']),
                  'phone_number' => sanitize_text_field($_POST['phone_number']),
                  'about_company' => sanitize_textarea_field($_POST['about_company']),
                  'cost_per_hour' => sanitize_text_field($_POST['cost_per_hour']),
                  'employee_range' => sanitize_text_field($_POST['employee_range']),
                  'facebook' => sanitize_text_field($_POST['facebook']),
                  'twitter' => sanitize_text_field($_POST['twitter']),
                  'linkedin' => sanitize_text_field($_POST['linkedin']),
                  'youtube' => sanitize_text_field($_POST['youtube']),
            );

            foreach ($company_profile as $key => $value) {
                  if (empty($value)) {
                        wp_send_json_error(array('message' => 'All fields are required'), 400);
                  }
            }

            update_post_meta($company_id, 'company_profile', json_encode($company_profile));

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step2');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function save_company_services()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $services_data = array(
                  'company_services' => array(
                        'artificial_intelligence' => sanitize_text_field($_POST['artificial_intelligence']),
                        'big_data_analytics' => sanitize_text_field($_POST['big_data_analytics']),
                        'blockchain' => sanitize_text_field($_POST['blockchain']),
                        'branding' => sanitize_text_field($_POST['branding']),
                        'cloud_computing' => sanitize_text_field($_POST['cloud_computing']),
                        'cyber_security' => sanitize_text_field($_POST['cyber_security']),
                        'digital_marketing' => sanitize_text_field($_POST['digital_marketing']),
                        'ecommerce_development' => sanitize_text_field($_POST['ecommerce_development']),
                        'enterprise_resource_planning' => sanitize_text_field($_POST['enterprise_resource_planning']),
                        'game_development' => sanitize_text_field($_POST['game_development']),
                        'iT_services' => sanitize_text_field($_POST['iT_services']),
                        'metaverse' => sanitize_text_field($_POST['metaverse']),
                        'mobile_app_development' => sanitize_text_field($_POST['mobile_app_development']),
                        'pr_firms' => sanitize_text_field($_POST['pr_firms']),
                        'testing' => sanitize_text_field($_POST['testing']),
                        'translation_services' => sanitize_text_field($_POST['translation_services']),
                        'uiUx_designing' => sanitize_text_field($_POST['uiUx_designing']),
                        'video_production' => sanitize_text_field($_POST['video_production']),
                        'wearable_app_development' => sanitize_text_field($_POST['wearable_app_development']),
                        'web_and_software_development' => sanitize_text_field($_POST['web_and_software_development']),
                        'business' => sanitize_text_field($_POST['business']),
                  ),
                  'company_sub_services' => $_POST['company_sub_services'] ?? array(),
            );

            foreach ($services_data['company_services'] as $key => $value) {
                  if (empty($value)) {
                        $text = str_replace('_', ' ', $key);
                        $text = ucwords($text);
                        wp_send_json_error(array('message' => $text . ' is required'), 400);
                  }
            }

            if (empty($services_data['company_sub_services'])) {
                  wp_send_json_error(array('message' => 'Select at least one company sub service.'), 400);
            }

            update_post_meta($company_id, 'company_services', json_encode($services_data['company_services']));
            update_post_meta($company_id, 'company_sub_services', json_encode($services_data['company_sub_services']));

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step3');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function save_company_business_address()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $business_address = array(
                  'business_address_line_1' => sanitize_text_field($_POST['business_address_line_1']),
                  'business_address_line_2' => sanitize_text_field($_POST['business_address_line_2']),
                  'business_state' => sanitize_text_field($_POST['business_state']),
                  'business_city' => sanitize_text_field($_POST['business_city']),
                  'business_zip_code' => sanitize_text_field($_POST['business_zip_code']),
            );

            foreach ($business_address as $key => $value) {
                  if (empty($value)) {
                        wp_send_json_error(array('message' => 'All fields are required'), 400);
                  }
            }

            update_post_meta($company_id, 'business_address', json_encode($business_address));

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step4');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function save_industry_focus()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $industry_focus = array(
                  'advertising_marketing' => sanitize_text_field($_POST['advertising_marketing']),
                  'automotive' => sanitize_text_field($_POST['automotive']),
                  'art_entertainment_music' => sanitize_text_field($_POST['art_entertainment_music']),
                  'business_services' => sanitize_text_field($_POST['business_services']),
                  'consumer_products_services' => sanitize_text_field($_POST['consumer_products_services']),
                  'education' => sanitize_text_field($_POST['education']),
                  'financial_payments' => sanitize_text_field($_POST['financial_payments']),
                  'gaming' => sanitize_text_field($_POST['gaming']),
                  'government' => sanitize_text_field($_POST['government']),
                  'healthcare_life_insurance' => sanitize_text_field($_POST['healthcare_life_insurance']),
                  'hospitality_leisure' => sanitize_text_field($_POST['hospitality_leisure']),
                  'information_technology' => sanitize_text_field($_POST['information_technology']),
                  'telecommunications' => sanitize_text_field($_POST['telecommunications']),
                  'legal_compliance' => sanitize_text_field($_POST['legal_compliance']),
                  'manufacturing' => sanitize_text_field($_POST['manufacturing']),
                  'media' => sanitize_text_field($_POST['media']),
                  'real_estate' => sanitize_text_field($_POST['real_estate']),
                  'transportation_logistics' => sanitize_text_field($_POST['transportation_logistics']),
                  'utilities' => sanitize_text_field($_POST['utilities']),
                  'retail' => sanitize_text_field($_POST['retail']),
                  'other_industries' => sanitize_text_field($_POST['other_industries']),
                  'energy_natural_resources' => sanitize_text_field($_POST['energy_natural_resources']),
                  'non_profit' => sanitize_text_field($_POST['non_profit']),
            );

            foreach ($industry_focus as $key => $value) {
                  if (empty($value)) {
                        wp_send_json_error(array('message' => 'All fields are required'), 400);
                  }
            }

            update_post_meta($company_id, 'industry_focus', json_encode($industry_focus));

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step5');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function invite_a_client_for_reviews()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $invite_email = sanitize_email($_POST['invite_email']);

            if (empty($invite_email)) {
                  wp_send_json_error(array('message' => 'Email is required'), 400);
            }

            $to = $invite_email;
            $headers = 'From: TopRatedWeb <wordpress@topratedwebdesign.com' . "\r\n";
            $subject = 'TopRatedWeb | Invitation for Reviews';
            $message = 'You have been invited to review the services of ' . get_the_title($company_id) . '. Please click on the link below to submit your review. ' . site_url() . '/review/' . $company_id;
            wp_mail($to, $subject, $message, $headers);

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step6');

            $html = ob_get_clean();

            wp_send_json_success(array(
                  'message' => 'Invitation Sent',
                  'html' => $html
            ), 200);
      }

      public function save_company_portfolio()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $portfolio = $_POST['portfolio'];

            if (empty($portfolio)) {
                  wp_send_json_error(array('message' => 'Portfolio is required'), 400);
            } else {
                  foreach ($portfolio as $key => $value) {
                        if (empty($_FILES['portfolio']['name'][$key]['image'])) {
                              wp_send_json_error(array('message' => 'Image is required'), 400);
                        }

                        if (empty($value['project_name']) || empty($value['description']) || empty($value['budget'])) {
                              wp_send_json_error(array('message' => 'All fields are required'), 400);
                        }
                  }
            }

            $portfolio_data = array();


            foreach ($portfolio as $key => $value) {
                  $image_path = '';
                  $upload_dir = get_stylesheet_directory() . '/wp-backend/assets/images/portfolio/';
                  $month_year = date('Y') . '/' . date('m');
                  if (!file_exists($upload_dir . $month_year)) {
                        mkdir($upload_dir . $month_year, 0755, true);
                  }

                  $images = $_FILES['portfolio'];

                  $image_name = $images['name'][$key]['image'];
                  $image_tmp_name = $images['tmp_name'][$key]['image'];
                  $image_size = $images['size'][$key]['image'];
                  $image_error = $images['error'][$key]['image'];

                  $image_ext = explode('.', $image_name);
                  $image_actual_ext = strtolower(end($image_ext));

                  $allowed = array('jpg', 'jpeg', 'png', 'gif', 'webp');
                  if (!in_array($image_actual_ext, $allowed)) {
                        wp_send_json_error(array('message' => 'Invalid Image Format'), 400);
                  }

                  if ($image_error !== 0) {
                        wp_send_json_error(array('message' => 'There was an error uploading your image'), 400);
                  }

                  if ($image_size > 5000000) { // 5MB
                        wp_send_json_error(array('message' => 'Your image is too large'), 400);
                  }

                  $image_name_new = uniqid('', true) . '.' . $image_actual_ext;
                  $image_path = $upload_dir . $month_year . '/' . $image_name_new;
                  move_uploaded_file($image_tmp_name, $image_path);

                  $portfolio_data[$key]['image'] = get_stylesheet_directory_uri() . '/wp-backend/assets/images/portfolio/' . $month_year . '/' . $image_name_new;
                  $portfolio_data[$key]['project_name'] = $value['project_name'];
                  $portfolio_data[$key]['description'] = $value['description'];
                  $portfolio_data[$key]['budget'] = $value['budget'];
            }

            global $wpdb;
            $table_name = 'company_portfolios';

            // Delete existing portfolio
            // $wpdb->delete($table_name, array('company_id' => $company_id), array('%d'));

            foreach ($portfolio_data as $key => $value) {
                  $data = array(
                        'company_id' => (int)$company_id,
                        'image' => $value['image'],
                        'name' => $value['project_name'],
                        'description' => $value['description'],
                        'budget' => (int)$value['budget'],
                  );
                  $formats = array('%d', '%s', '%s', '%s', '%d');
                  $wpdb->insert($table_name, $data, $formats);
            }

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step7');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function save_company_faqs()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $faqs = $_POST['faq'];

            if (empty($faqs)) {
                  wp_send_json_error(array('message' => 'FAQs are required'), 400);
            } else {
                  foreach ($faqs as $key => $value) {
                        if (empty($value['question']) || empty($value['answer'])) {
                              wp_send_json_error(array('message' => 'All fields are required'), 400);
                        }
                  }
            }

            global $wpdb;
            $table_name = 'company_faqs';

            // Delete existing faqs
            $wpdb->delete($table_name, array('company_id' => $company_id), array('%d'));

            foreach ($faqs as $key => $value) {
                  $data = array(
                        'company_id' => (int)$company_id,
                        'question' => $value['question'],
                        'answer' => $value['answer'],
                  );
                  $formats = array('%d', '%s', '%s');
                  $wpdb->insert($table_name, $data, $formats);
            }

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step8');
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function save_company_employees()
      {
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            $employees = $_POST['employee'];

            if (empty($employees)) {
                  wp_send_json_error(array('message' => 'Employees are required'), 400);
            } else {
                  foreach ($employees as $key => $value) {
                        if (empty($_FILES['employee']['name'][$key]['image'])) {
                              wp_send_json_error(array('message' => 'Image is required'), 400);
                        }

                        if (empty($value['name']) || empty($value['job_title']) || empty($value['about'])) {
                              wp_send_json_error(array('message' => 'All fields are required'), 400);
                        }
                  }
            }

            $employees_data = array();

            foreach ($employees as $key => $value) {
                  $image_path = '';
                  $upload_dir = get_stylesheet_directory() . '/wp-backend/assets/images/employees/';
                  $month_year = date('Y') . '/' . date('m');
                  if (!file_exists($upload_dir . $month_year)) {
                        mkdir($upload_dir . $month_year, 0755, true);
                  }

                  $images = $_FILES['employee'];

                  $image_name = $images['name'][$key]['image'];
                  $image_tmp_name = $images['tmp_name'][$key]['image'];
                  $image_size = $images['size'][$key]['image'];
                  $image_error = $images['error'][$key]['image'];

                  $image_ext = explode('.', $image_name);
                  $image_actual_ext = strtolower(end($image_ext));

                  $allowed = array('jpg', 'jpeg', 'png', 'gif', 'webp');
                  if (!in_array($image_actual_ext, $allowed)) {
                        wp_send_json_error(array('message' => 'Invalid Image Format'), 400);
                  }

                  if ($image_error !== 0) {
                        wp_send_json_error(array('message' => 'There was an error uploading your image'), 400);
                  }

                  if ($image_size > 5000000) { // 5MB
                        wp_send_json_error(array('message' => 'Your image is too large'), 400);
                  }

                  $image_name_new = uniqid('', true) . '.' . $image_actual_ext;
                  $image_path = $upload_dir . $month_year . '/' . $image_name_new;
                  move_uploaded_file($image_tmp_name, $image_path);

                  $employees_data[$key]['image'] = get_stylesheet_directory_uri() . '/wp-backend/assets/images/employees/' . $month_year . '/' . $image_name_new;
                  $employees_data[$key]['name'] = $value['name'];
                  $employees_data[$key]['job_title'] = $value['job_title'];
                  $employees_data[$key]['about'] = $value['about'];

                  global $wpdb;
                  $table_name = 'company_employees';

                  // Delete existing employees
                  // $wpdb->delete($table_name, array('company_id' => $company_id), array('%d'));

                  foreach ($employees_data as $key => $value) {
                        $data = array(
                              'company_id' => (int)$company_id,
                              'image' => $value['image'],
                              'name' => $value['name'],
                              'job_title' => $value['job_title'],
                              'about' => $value['about'],
                        );
                        $formats = array('%d', '%s', '%s', '%s', '%s');
                        $wpdb->insert($table_name, $data, $formats);
                  }

                  wp_send_json_success(array(
                        'redirect' => site_url('company-profile')
                  ), 200);
            }
      }

      public function update_account_details()
      {
            $user_id = wp_get_current_user()->ID;
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $email = sanitize_email($_POST['email']);
            $phone_number = sanitize_text_field($_POST['phone_number']);
            $company_name = sanitize_text_field($_POST['company_name']);
            $designation = sanitize_text_field($_POST['designation']);

            if (empty($first_name) || empty($last_name) || empty($email) || empty($phone_number) || empty($company_name) || empty($designation)) {
                  wp_send_json_error(array('message' => 'All fields are required'), 400);
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  wp_send_json_error(array('message' => 'Invalid Email'), 400);
            }

            $user_data = array(
                  'ID' => $user_id,
                  'first_name' => $first_name,
                  'last_name' => $last_name,
                  'user_email' => $email,
            );

            wp_update_user($user_data);

            update_user_meta($user_id, 'phone_number', $phone_number);
            update_user_meta($user_id, 'company_name', $company_name);
            update_user_meta($user_id, 'designation', $designation);

            wp_send_json_success(array(
                  'message' => 'Account Details Updated'
            ), 200);
      }

      public function update_user_password()
      {
            $user_id = wp_get_current_user()->ID;
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                  wp_send_json_error(array('message' => 'All fields are required'), 400);
            }

            if ($new_password != $confirm_password) {
                  wp_send_json_error(array('message' => 'Password does not match'), 400);
            }

            $user = wp_authenticate(get_userdata($user_id)->user_email, $current_password);

            if (is_wp_error($user)) {
                  wp_send_json_error(array('message' => 'Invalid Current Password'), 400);
            }

            wp_set_password($new_password, $user_id);

            wp_send_json_success(array(
                  'message' => 'Password Updated'
            ), 200);
      }

      public function company_form_prev()
      {
            $step = (int)$_POST['step']; // 1, 2, 3, 4, 5, 6, 7, 8
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step' . $step);
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }

      public function company_form_specific_step()
      {
            $step = (int)$_POST['step']; // 1, 2, 3, 4, 5, 6, 7, 8
            $company_id = wp_get_current_user()->company_id;

            if (empty($company_id)) {
                  wp_send_json_error(array('message' => 'Unauthorized Access'), 400);
            }

            ob_start();
            get_template_part('wp-backend/templates/company/company-create', 'step' . $step);
            $html = ob_get_clean();

            wp_send_json_success(array(
                  'html' => $html
            ), 200);
      }
      public function project_sort()
      {
            $sort = $_POST['sort'];
            $category = $_POST['category'];

            // Create an array of arguments for your query.
            $args = array(
                  'post_type' => 'portfolio',
                  'post_status' => 'publish',
                  'posts_per_page' => -1,
            );

            // If the category is not 'All Projects', add the 'tax_query' to the arguments.
            if ($category !== 'All Projects') {
                  $args['tax_query'] = array(
                        array(
                              'taxonomy' => 'project-cat',
                              'field'    => 'name',
                              'terms'    => $category,
                        ),
                  );
            }

            // Set the 'orderby' and 'order' parameters depending on the 'sort' value.
            switch ($sort) {
                  case 'updated-new-to-old':
                        $args['orderby'] = 'modified';
                        $args['order'] = 'DESC';
                        break;
                  case 'updated-old-to-new':
                        $args['orderby'] = 'modified';
                        $args['order'] = 'ASC';
                        break;
                  case 'alphabetical-a-z':
                        $args['orderby'] = 'title';
                        $args['order'] = 'ASC';
                        break;
                  case 'alphabetical-z-a':
                        $args['orderby'] = 'title';
                        $args['order'] = 'DESC';
                        break;
            }

            // Run the query.
            $query = new WP_Query($args);

            // Check if any posts were found.
            if ($query->have_posts()) {
                  ob_start();
                  while ($query->have_posts()) : $query->the_post();
?>
                        <div class="project-item">
                              <?php if (has_post_thumbnail()) : ?>
                                    <?php
                                    $thumbnail_id = get_post_thumbnail_id();
                                    $thumbnail = wp_get_attachment_image($thumbnail_id, 'full', false, array('class' => 'img-style'));
                                    echo $thumbnail;
                                    ?>
                              <?php endif; ?>
                        </div>
<?php
                  endwhile;
                  $html = ob_get_clean();
            } else {
                  $html = 'No project found for that category';
            }

            // Restore original Post Data
            wp_reset_postdata();

            echo $html;

            wp_die(); // this is required to terminate immediately and return a proper response
      }
} //Class Ends here
