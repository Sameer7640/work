<?php
// post types code

// COMPANY POST TYPE
function company_post_type()
{
    $labels = array(
        'name'                  => _x('Companies', 'Post Type General Name', 'c3'),
        'singular_name'         => _x('Company', 'Post Type Singular Name', 'c3'),
        'menu_name'             => __('Companies', 'c3'),
        'name_admin_bar'        => __('Company', 'c3'),
        'archives'              => __('Company Archives', 'c3'),
        'attributes'            => __('Company Attributes', 'c3'),
        'parent_item_colon'     => __('Parent Company:', 'c3'),
        'all_items'             => __('All Companies', 'c3'),
        'add_new_item'          => __('Add New Company', 'c3'),
        'add_new'               => __('Add New', 'c3'),
        'new_item'              => __('New Company', 'c3'),
        'edit_item'             => __('Edit Company', 'c3'),
        'update_item'           => __('Update Company', 'c3'),
        'view_item'             => __('View Company', 'c3'),
        'view_items'            => __('View Companies', 'c3'),
        'search_items'          => __('Search Company', 'c3'),
        'not_found'             => __('Not found', 'c3'),
        'not_found_in_trash'    => __('Not found in Trash', 'c3'),
        'featured_image'        => __('Featured Image', 'c3'),
        'set_featured_image'    => __('Set featured image', 'c3'),
        'remove_featured_image' => __('Remove featured image', 'c3'),
        'use_featured_image'    => __('Use as featured image', 'c3'),
        'insert_into_item'      => __('Insert into company', 'c3'),
        'uploaded_to_this_item' => __('Uploaded to this company', 'c3'),
        'items_list'            => __('Companies list', 'c3'),
        'items_list_navigation' => __('Companies list navigation', 'c3'),
        'filter_items_list'     => __('Filter companies list', 'c3'),
    );

    $args = array(
        'label'                 => __('Company', 'c3'),
        'description'           => __('Company Description', 'c3'),
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'custom-fields',),
        'taxonomies'            => array(''),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-building',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'map_meta_cap'          => true,
        'capabilities'          => array(
            'create_posts' => 'do_not_allow',
        ),
    );

    register_post_type('company', $args);
}

add_action('init', 'company_post_type', 0);

add_filter('post_row_actions', 'remove_row_actions', 10, 1);
function remove_row_actions($actions)
{
    if (get_post_type() === 'company') {
        unset($actions['edit']);
        unset($actions['view']);
        unset($actions['trash']);
        unset($actions['inline hide-if-no-js']);
    }
    return $actions;
}
