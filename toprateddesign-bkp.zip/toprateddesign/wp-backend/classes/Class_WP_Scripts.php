<?php

/**
 * Enqueue Additional Styles & Scripts
 */

class Class_WP_Scripts
{
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'wp_client_enqueue_scripts']);
    }

    public function wp_client_enqueue_scripts()
    {
        // Loader
        wp_enqueue_script('loadingoverlay-min-js', get_stylesheet_directory_uri() . '/wp-backend/vendor/loader/loadingoverlay.min.js', array(), '2.1.7', true);

        // Bootstrap
        // wp_enqueue_style('bootstrap-utilities-css', get_stylesheet_directory_uri() . '/wp-backend/assets/css/bootstrap-utilities.min.css', array(), '1.0.0', 'all');
        wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css', array(), '1.0.0', 'all');
        wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.bundle.min.js', array(), '1.0.0', true);

        //sweetalert
        wp_enqueue_style('sweetalert-bootstrap-min', get_stylesheet_directory_uri() . '/wp-backend/vendor/sweetalert/sweetalert-bootstrap.min.css', array(), '4.0.0', 'all');
        wp_enqueue_script('sweetalert-min-js', get_stylesheet_directory_uri() . '/wp-backend/vendor/sweetalert/sweetalert.js', array(), '11.7.3', true);

        // validate
        wp_enqueue_script('jquery-validate-min-js', get_stylesheet_directory_uri() . '/wp-backend/vendor/validate/jquery.validate.min.js', array(), '1.19.5', true);

        wp_enqueue_style('dashboard-css', get_stylesheet_directory_uri() . '/wp-backend/assets/css/dashboard.css', array(), rand(111, 9999), 'all');

        wp_enqueue_script('scripts-handler-js', get_stylesheet_directory_uri() . '/wp-backend/assets/js/scripts-handler.js', array('jquery-validate-min-js', 'loadingoverlay-min-js', 'sweetalert-min-js'), '1.0.0', true);

        wp_localize_script(
            'scripts-handler-js',
            'handler_object',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'site_url' => site_url(),
            )
        );
    }
}
