<?php

/**
 * Custom Shortcodes
 */
class Class_WP_Shortcode
{

    public function __construct()
    {
        add_shortcode('cs-template-name', [$this, 'cs_template_shortcode_wp']);

        add_shortcode('auth_link', [$this, 'auth_link_shortcode']);
    }

    public function cs_template_shortcode_wp($atts)
    {
        $atts = shortcode_atts(array(
            'page' => ''
        ), $atts);
        ob_start();

        get_template_part($atts['page']);
        return ob_get_clean();
    }

    /* 
    <a href="https://topratedwebdesign.com/login/" title="" class="btn btn-color-black btn-style-link btn-style-rectangle btn-size-default header-link-btn btn-icon-pos-right">Login<span class="wd-btn-icon"><img width="17" height="17" src="https://topratedwebdesign.com/wp-content/uploads/2024/03/SVG-17x17.png" class="attachment-17x17 size-17x17" alt="" decoding="async"></span></a>
    */

    public function auth_link_shortcode($atts)
    {
        if (is_user_logged_in()) {
            $link = wp_logout_url(site_url());
            $text = 'Logout';
        } else {
            $link = site_url() . '/login';
            $text = 'Login';
        }

?>
        <a href="<?php echo $link; ?>" class="btn btn-color-black btn-style-link btn-style-rectangle btn-size-default header-link-btn btn-icon-pos-right">
            <?php echo $text; ?>
            <span class="wd-btn-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="22" height="22">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                </svg>
            </span>
        </a>
<?php

    }
}
