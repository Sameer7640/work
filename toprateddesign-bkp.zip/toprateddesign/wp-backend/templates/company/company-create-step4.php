<?php
$post_id = wp_get_current_user()->company_id;

$industry_focus = get_post_meta($post_id, 'industry_focus', true);
if ($industry_focus) {
    $industry_focus = json_decode($industry_focus, true);
} else {
    $industry_focus = array();
}
?>
<form class="submit-form-using-ajax">
    <div class="company-form-content">
        <h4>Industry Focus</h4>
        <hr>
        <div class="row">
            <?php
            $industry_focus_array = array(
                'Advertising & Marketing (%)',
                'Automotive (%)',
                'Art. Entertainment & Music (%)',
                'Business Services (%)',
                'Consumer Products & Services (%)',
                'Education (%)',
                'Financial & Payments (%)',
                'Gaming (%)',
                'Government (% )',
                'Healthcare & Life Insurance (%)',
                'Hospitality &   Leisure (%)',
                'Information Technology (%)',
                'Telecommunications (%)',
                'Legal Compliance (%)',
                'Manufacturing (%)',
                'Media (%)',
                'Real Estate (%)',
                'Transportation & Logistics (%)',
                'Utilities (%)',
                'Retail (%)',
                'Other Industries (%)',
                'Energy & Natural Resources (%)',
                'Non-Profit (%)'
            ); ?>

            <?php foreach ($industry_focus_array as $industry) : ?>
                <?php
                $industry = strtolower(str_replace('-', ' ', $industry));
                $strip_special_characters = preg_replace('/[^A-Za-z0-9\s\-]/', '', $industry);
                $strip_special_characters = rtrim($strip_special_characters);
                $strip_special_characters = preg_replace('/\s+/', ' ', $strip_special_characters);

                $industry_item = strtolower(str_replace(' ', '_', $strip_special_characters));
                ?>

                <div class="col-md-6 col-lg-4">
                    <div class="form-group">
                        <label>
                            <span class="label-text"><?php echo $industry; ?></span>
                            <input type="number" placeholder="0" name="<?php echo $industry_item; ?>" value="<?php echo array_key_exists($industry_item, $industry_focus) ? $industry_focus[$industry_item] : ''; ?>">
                        </label>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Form Footer Actions -->
    <div class="company-form-footer">
        <input type="hidden" name="action" value="save_industry_focus">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-company-form-prev btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn" data-step="3">Back</button>
            </div>
            <!-- <div class="col-auto">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
            </div> -->
            <div class="col-auto">
                <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>