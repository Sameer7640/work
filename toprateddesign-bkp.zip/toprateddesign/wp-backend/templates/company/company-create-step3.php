<?php
$post_id = wp_get_current_user()->company_id;

$business_address = get_post_meta($post_id, 'business_address', true);
if ($business_address) {
    $business_address = json_decode($business_address, true);
} else {
    $business_address = array();
}

?>
<form class="submit-form-using-ajax">
    <div class="company-form-content">
        <h4>Business Address</h4>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Address Line 1 *</span>
                        <input type="text" name="business_address_line_1" placeholder="Description Here" value="<?php echo array_key_exists('business_address_line_1', $business_address) ? $business_address['business_address_line_1'] : ''; ?>" required>
                    </label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Address Line 2</span>
                        <input type="text" name="business_address_line_2" placeholder="Description Here" value="<?php echo array_key_exists('business_address_line_2', $business_address) ? $business_address['business_address_line_2'] : ''; ?>">
                    </label>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label>
                        <span class="label-text">State *</span>
                        <select name="business_state" id="business_state" required>
                            <option value="">Select State</option>
                            <?php
                            $states = array(
                                'Alabama' => 'AL',
                                'Alaska' => 'AK',
                                'Arizona' => 'AZ',
                                'Arkansas' => 'AR',
                                'American Samoa' => 'AS',
                                'California' => 'CA',
                                'Colorado' => 'CO',
                                'Connecticut' => 'CT',
                                'Delaware' => 'DE',
                                'District of Columbia' => 'DC',
                                'Florida' => 'FL',
                                'Georgia' => 'GA',
                                'Guam' => 'GU',
                                'Hawaii' => 'HI',
                                'Idaho' => 'ID',
                                'Illinois' => 'IL',
                                'Indiana' => 'IN',
                                'Iowa' => 'IA',
                                'Kansas' => 'KS',
                                'Kentucky' => 'KY',
                                'Louisiana' => 'LA',
                                'Maine' => 'ME',
                                'Maryland' => 'MD',
                                'Massachusetts' => 'MA',
                                'Michigan' => 'MI',
                                'Minnesota' => 'MN',
                                'Mississippi' => 'MS',
                                'Missouri' => 'MO',
                                'Montana' => 'MT',
                                'Nebraska' => 'NE',
                                'Nevada' => 'NV',
                                'New Hampshire' => 'NH',
                                'New Jersey' => 'NJ',
                                'New Mexico' => 'NM',
                                'New York' => 'NY',
                                'North Carolina' => 'NC',
                                'North Dakota' => 'ND',
                                'Northern Mariana Islands' => 'MP',
                                'Ohio' => 'OH',
                                'Oklahoma' => 'OK',
                                'Oregon' => 'OR',
                                'Pennsylvania' => 'PA',
                                'Puerto Rico' => 'PR',
                                'Rhode Island' => 'RI',
                                'South Carolina' => 'SC',
                                'South Dakota' => 'SD',
                                'Tennessee' => 'TN',
                                'Texas' => 'TX',
                                'Trust Territories' => 'TT',
                                'Utah' => 'UT',
                                'Vermont' => 'VT',
                                'Virginia' => 'VA',
                                'Washington' => 'WA',
                                'West Virginia' => 'WV',
                                'Wisconsin' => 'WI',
                                'Wyoming' => 'WY'
                            );

                            foreach ($states as $state => $code) {
                                $selected = '';
                                if (array_key_exists('business_state', $business_address) && $business_address['business_state'] == $code) {
                                    $selected = 'selected';
                                }
                            ?>
                                <option value="<?php echo $code; ?>" <?php echo $selected; ?>><?php echo $state; ?></option>
                            <?php }
                            ?>
                        </select>
                    </label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">City</span>
                        <input type="text" name="business_city" placeholder="Select Country" value="<?php echo array_key_exists('business_city', $business_address) ? $business_address['business_city'] : ''; ?>" required>
                    </label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Zip Code *</span>
                        <input type="text" name="business_zip_code" placeholder="Zip Code" value="<?php echo array_key_exists('business_zip_code', $business_address) ? $business_address['business_zip_code'] : ''; ?>" required>
                    </label>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Footer Actions -->
    <div class="company-form-footer">
        <input type="hidden" name="action" value="save_company_business_address">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-company-form-prev btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn" data-step="2">Back</button>
            </div>
            <!-- <div class="col-auto">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
            </div> -->
            <div class="col-auto">
                <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>