<?php

$post_id = wp_get_current_user()->company_id;
$company_data = get_post_meta($post_id, 'company_profile', true);
if ($company_data) {
    $company_data = json_decode($company_data, true);
} else {
    $company_data = array();
}
?>


<form class="submit-form-using-ajax">
    <!-- Company Profile -->
    <div class="company-form-content">
        <h4>Company Profile</h4>
        <hr>
        <div class="row">
            <div class="col-md-3">
                <label class="image-file-selector">
                    <input type="file" name="company_profile_image" accept="image/*">
                    <?php
                    if (has_post_thumbnail($post_id)) :
                        $thumbnail = get_the_post_thumbnail_url($post_id, 'large');
                    ?>
                        <img src="<?php echo $thumbnail; ?>" alt="">
                    <?php else : ?>
                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/03/Image-1.jpg" alt="">
                    <?php endif; ?>
                    <span class="label-text">
                        Upload Logo *
                    </span>
                </label>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Company Name *</span>
                                <input type="text" placeholder="Company Name" name="company_name" value="<?php echo array_key_exists('company_name', $company_data) ? $company_data['company_name'] : ''; ?>" required>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Year Founded *</span>
                                <select name="year_found" required>
                                    <option value="">Year Founded</option>
                                    <?php for ($i = 2024; $i >= 1900; $i--) : ?>
                                        <option value="<?php echo $i; ?>" <?php echo array_key_exists('year_found', $company_data) && $company_data['year_found'] == $i ? 'selected' : ''; ?>>
                                            <?php echo $i; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Tag Line *</span>
                                <input type="text" placeholder="Top Rated Web Design & Development" name="tag_line" value="<?php echo array_key_exists('tag_line', $company_data) ? $company_data['tag_line'] : ''; ?>" required>
                            </label>
                        </div>
                    </div>
                    <div class=" col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Email *</span>
                                <input type="email" placeholder="Email" name="email" value="<?php echo array_key_exists('email', $company_data) ? $company_data['email'] : ''; ?>" required>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Min. Project Amount*</span>
                                <select name="min_project_amount" required>
                                    <option value="">Min. Project Amount</option>
                                    <?php for ($i = 500; $i <= 10000; $i += 500) : ?>
                                        <option value="<?php echo '$' . $i . '-' . '$' . ($i + 500); ?>" <?php echo array_key_exists('min_project_amount', $company_data) && $company_data['min_project_amount'] == '$' . $i . '-' . '$' . ($i + 500) ? 'selected' : ''; ?>>
                                            <?php echo '$' . $i . '-' . '$' . ($i + 500); ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Website *</span>
                                <input type="text" placeholder="Website" name="website" value="<?php echo array_key_exists('website', $company_data) ? $company_data['website'] : ''; ?>" required>
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>
                                <span class="label-text">Phone Number *</span>
                                <input type="text" placeholder="Phone Number" name="phone_number" value="<?php echo array_key_exists('phone_number', $company_data) ? $company_data['phone_number'] : ''; ?>" required>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label>
                        <span class="label-text">About Company *</span>
                        <textarea name="about_company" id="" cols="30" rows="4" placeholder="About Company" required><?php echo array_key_exists('about_company', $company_data) ? $company_data['about_company'] : ''; ?></textarea>
                    </label>
                </div>
            </div>
        </div>
    </div>
    <!-- Company Profile -->

    <!-- Cost Per Hour & Employee Range -->
    <div class="company-form-content">
        <h4>Cost Per Hour & Employee Range</h4>
        <hr>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Cost Per Hour *</span>
                        <select name="cost_per_hour" required>
                            <option value="">Cost Per Hour</option>
                            <?php for ($i = 0; $i <= 250; $i += 50) : ?>
                                <option value="<?php echo '$' . $i . ' - $' . ($i + 50); ?>" <?php echo array_key_exists('cost_per_hour', $company_data) && $company_data['cost_per_hour'] == '$' . $i . ' - $' . ($i + 50) ? 'selected' : ''; ?>>
                                    <?php echo '$' . $i . ' - $' . ($i + 50); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Employee Range *</span>
                        <select name="employee_range" required>
                            <option value="">Employee Range</option>
                            <?php for ($i = 0; $i <= 500; $i += 50) : ?>
                                <option value="<?php echo $i . ' - ' . ($i + 50); ?>" <?php echo array_key_exists('employee_range', $company_data) && $company_data['employee_range'] == $i . ' - ' . ($i + 50) ? 'selected' : ''; ?>>
                                    <?php echo $i . ' - ' . ($i + 50); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </label>
                </div>
            </div>
        </div>
    </div>
    <!-- Cost Per Hour & Employee Range -->

    <!-- Social Connections -->
    <div class="company-form-content">
        <h4>Social Connections</h4>
        <hr>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Facebook</span>
                        <input type="url" placeholder="Facebook URL" name="facebook" value="<?php echo array_key_exists('facebook', $company_data) ? $company_data['facebook'] : ''; ?>" required>
                    </label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Twitter</span>
                        <input type="url" placeholder="Twitter URL" name="twitter" value="<?php echo array_key_exists('twitter', $company_data) ? $company_data['twitter'] : ''; ?>" required>
                    </label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">Linkedin</span>
                        <input type="url" placeholder="Linkedin URL" name="linkedin" value="<?php echo array_key_exists('linkedin', $company_data) ? $company_data['linkedin'] : ''; ?>" required>
                    </label>
                </div>
            </div>
            <div class=" col-lg-6">
                <div class="form-group">
                    <label>
                        <span class="label-text">YouTube Channel</span>
                        <input type="url" placeholder="Youtube URL" name="youtube" value="<?php echo array_key_exists('youtube', $company_data) ? $company_data['youtube'] : ''; ?>" required>
                    </label>
                </div>
            </div>
        </div>
    </div>
    <!-- Social Connections -->

    <!-- Form Footer Actions -->
    <div class=" company-form-footer">
        <input type="hidden" name="action" value="save_company_profile_data">
        <div class="row">
            <!-- <div class="col">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Back</button>
            </div>
            <div class="col-auto">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
            </div> -->
            <div class="col-auto">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>