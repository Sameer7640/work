<?php

global $wpdb;
$company_id = wp_get_current_user()->company_id;
$employees = $wpdb->get_results("SELECT * FROM company_employees WHERE company_id = $company_id", ARRAY_A);
?>

<form class="submit-form-using-ajax">
    <div class="company-form-content">
        <div class="row align-items-center">
            <div class="col-12 col-md-6">
                <h4>Employees</h4>
            </div>
            <div class="col-12 col-md-6 text-md-right">
                <button class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3 add-portfolio">Add Employee</button>
            </div>
        </div>
        <hr>
        <div class="row" data-porfolio-row>
            <?php
            if ($employees) :
                foreach ($employees as $key => $value) : ?>
                    <div class="col-md-6 col-lg-4" data-portfolio-item>
                        <div class="portfolio-item">
                            <?php if ($key != 0) : ?>
                                <button type="button" class="btn btn-remove-portfolio">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="20" height="20">
                                        <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"></path>
                                    </svg>
                                </button>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="image-file-selector">
                                    <input type="file" name="employee[0][image]">
                                    <img src="<?php echo $value['image'] ? site_url() . '/wp-content/uploads/2024/03/Image-1.jpg' : site_url() . '/wp-content/uploads/2024/03/Image-1.jpg'; ?>" alt="">
                                </label>
                            </div>
                            <div class="form-group">
                                <label>
                                    <span class="label-text">Name</span>
                                    <input type="text" placeholder="Name" name="employee[0][name]" value="<?php echo $value['name']; ?>">
                                </label>
                            </div>
                            <div class="form-group">
                                <label>
                                    <span class="label-text">Job Title</span>
                                    <input type="text" placeholder="Job Title" name="employee[0][job_title]" value="<?php echo $value['job_title']; ?>">
                                </label>
                            </div>
                            <div class="form-group">
                                <label>
                                    <span class="label-text">About</span>
                                    <textarea name="employee[0][about]" id="" cols="30" rows="2" placeholder="About"><?php echo $value['about']; ?></textarea>
                                </label>
                            </div>
                        </div>
                    </div>
                <?php endforeach;
            else : ?>
                <div class="col-md-6 col-lg-4" data-portfolio-item>
                    <div class="portfolio-item">
                        <div class="form-group">
                            <label class="image-file-selector">
                                <input type="file" name="employee[0][image]">
                                <img src="<?php echo site_url() . '/wp-content/uploads/2024/03/Image-1.jpg'; ?>" alt="">
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <span class="label-text">Name</span>
                                <input type="text" placeholder="Name" name="employee[0][name]">
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <span class="label-text">Job Title</span>
                                <input type="text" placeholder="Job Title" name="employee[0][job_title]">
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <span class="label-text">About</span>
                                <textarea name="employee[0][about]" id="" cols="30" rows="2" placeholder="About"></textarea>
                            </label>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Form Footer Actions -->
    <div class=" company-form-footer">
        <input type="hidden" name="action" value="save_company_employees">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-company-form-prev btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn" data-step="7">Back</button>
            </div>
            <!-- <div class="col-auto">
<button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
</div> -->
            <div class="col-auto">
                <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>