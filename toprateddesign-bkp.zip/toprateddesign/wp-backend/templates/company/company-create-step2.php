<?php
$post_id = wp_get_current_user()->company_id;

$company_services = get_post_meta($post_id, 'company_services', true);
if ($company_services) {
    $company_services = json_decode($company_services, true);
} else {
    $company_services = array();
}

$company_sub_services_list = get_post_meta($post_id, 'company_sub_services', true);
if ($company_sub_services_list) {
    $company_sub_services_list = json_decode($company_sub_services_list, true);
} else {
    $company_sub_services_list = array();
}

?>

<form class="submit-form-using-ajax">
    <div class="company-form-content">
        <nav>
            <div class="nav company-form-tabs" id="nav-tab" role="tablist">
                <a class="active" id="company-services-tab-title" data-toggle="tab" href="#company-services-tab" role="tab" aria-controls="company-services-tab" aria-selected="true">
                    <h4 class="mb-0">
                        Company Services
                    </h4>
                </a>
                <a id="company-sub-services-tab-title" data-toggle="tab" href="#company-sub-services" role="tab" aria-controls="company-sub-services" aria-selected="false">
                    <h4 class="mb-0">
                        Company Sub Services
                    </h4>
                </a>
            </div>
        </nav>
        <hr>
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="company-services-tab" role="tabpanel" aria-labelledby="company-services-tab-title">
                <div class="row">
                    <?php
                    $services = array(
                        'artificial_intelligence' => 'Artificial Intelligence',
                        'big_data_analytics' => 'Big Data Analytics',
                        'blockchain' => 'Blockchain',
                        'branding' => 'Branding',
                        'cloud_computing' => 'Cloud Computing',
                        'cyber_security' => 'Cybersecurity',
                        'digital_marketing' => 'Digital Marketing',
                        'ecommerce_development' => 'Ecommerce Development',
                        'enterprise_resource_planning' => 'Enterprise Resource Planning',
                        'game_development' => 'Game Development',
                        'iT_services' => 'IT Services',
                        'metaverse' => 'Metaverse',
                        'mobile_app_development' => 'Mobile App Development',
                        'pr_firms' => 'PR Firms',
                        'testing' => 'Testing',
                        'translation_services' => 'Translation Servies',
                        'uiUx_designing' => 'UI/UX Designing',
                        'video_production' => 'Video Production',
                        'wearable_app_development' => 'Wearable App Development',
                        'web_and_software_development' => 'Web and Software Development',
                        'business' => 'Business'
                    );

                    foreach ($services as $key => $label) : ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                                <label>
                                    <span class="label-text"><?php echo $label; ?></span>
                                    <input type="number" placeholder="0" name="<?php echo $key; ?>" value="<?php echo array_key_exists($key, $company_services) ? $company_services[$key] : ''; ?>" required>
                                </label>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="tab-pane fade" id="company-sub-services" role="tabpanel" aria-labelledby="company-sub-services-tab-title">
                <?php
                $company_sub_services = array(
                    'Mobile App Development' => array(
                        'Swift',
                        'Internet Of Things',
                        'Hybrid',
                        'Enterprise App',
                        'Augmented Reality',
                        'Virtual Reality',
                        'React Native',
                        'Flutter',
                        'App Design',
                        'Android App',
                        'iPhone App',
                        'iPad Design'
                    ),
                    'Framework and CMS' => array(
                        '.NET',
                        'Adobe',
                        'Cake PHP',
                        'Codeigniter',
                        'Django',
                        'DNN (DotNetDuke)',
                        'Drupal',
                        'Ektron',
                        'Expression Engine',
                        'HP',
                        'IBM',
                        'Joomla',
                        'Laravel',
                        'Oracle',
                        'Ruby on Rails',
                        'SDL',
                        'Microsoft SharePoint',
                        'Sitecore',
                        'Spring MVC',
                        'Struts',
                        'Symfony',
                        'WordPress',
                        'Zend',
                        'Zope',
                        'Other frameworks and CMs',
                        'Yii',
                        'MEAN Stack',
                        'MERN Stack',
                        'Full Stack Developers',
                        'Back End Developers',
                        'Front End Developers',
                        'WordPress Web Design',
                        'DevOps Developers'
                    ),
                    'Programming and Scripting' => array(
                        'AJAX',
                        'Apex',
                        'ASP',
                        'ASP.NET',
                        'C',
                        'C#',
                        'C++',
                        'Cold Fusion',
                        'Delphi',
                        'Java',
                        'JavaScript',
                        'Objective C',
                        'Perl',
                        'PHP',
                        'Python',
                        'Ruby',
                        'SQL',
                        'Virtual Basic',
                        'XML',
                        'Other Programming & Scripting Languages',
                        'Angular JS',
                        'NodeJS',
                        'React JS',
                        'Vue JS '
                    ),
                    'Web and Software Development' => array(
                        'Web Development',
                        'Software Development',
                        'Progressive Web App (PWA)',
                        'Web Design',
                    ),
                );

                foreach ($company_sub_services as $category => $label) : ?>
                    <div class="row">
                        <div class="col-12">
                            <h4><?php echo $category; ?></h4>
                            <div class="row">
                                <?php
                                $label_handle = strtolower(str_replace(' ', '_', $category));
                                foreach ($label as $key => $sub_service) : ?>
                                    <?php
                                    $strip_special_characters = preg_replace('/[^A-Za-z0-9\s\-]/', '', $sub_service);
                                    $strip_special_characters = rtrim($strip_special_characters);
                                    $strip_special_characters = preg_replace('/\s+/', ' ', $strip_special_characters);

                                    $service_item = strtolower(str_replace(' ', '_', $strip_special_characters));
                                    ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="checkbox-group">
                                            <label>
                                                <input type="checkbox" name="company_sub_services[<?php echo $label_handle; ?>][]" value="<?php echo $service_item; ?>" <?php echo array_key_exists($label_handle, $company_sub_services_list) && in_array($service_item, $company_sub_services_list[$label_handle]) ? 'checked' : ''; ?> <span class="label-text"><?php echo $sub_service; ?></span>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Form Footer Actions -->
    <div class=" company-form-footer">
        <input type="hidden" name="action" value="save_company_services">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-company-form-prev btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn" data-step="1">Back</button>
            </div>
            <!-- <div class="col-auto">
                <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
            </div> -->
            <div class="col-auto">
                <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>