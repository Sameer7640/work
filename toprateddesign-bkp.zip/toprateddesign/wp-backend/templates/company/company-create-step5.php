<form class="submit-form-using-ajax">
    <div class="company-form-content">
        <h4>Reviews</h4>
        <hr>
        <p>You have not received any reviews yet.</p>
        <div class="row align-items-end">
            <div class="col-12 col-md">
                <div class="form-group">
                    <label>
                        <span class="label-text">Invite a Client</span>
                        <input type="email" placeholder="Email" name="invite_email" required>
                    </label>
                </div>
            </div>
            <div class="col-12 col-md-auto">
                <input type="hidden" name="action" value="invite_a_client_for_reviews">
                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3">Invite</button>
            </div>
        </div>
    </div>
</form>