<?php

global $wpdb;
$company_id = wp_get_current_user()->company_id;
$faqs = $wpdb->get_results("SELECT * FROM company_faqs WHERE company_id = $company_id", ARRAY_A);

?>

<form action="" class="submit-form-using-ajax">
    <div class="company-form-content">
        <h4>FAQS</h4>
        <hr>
        <?php if ($faqs) : ?>
            <?php foreach ($faqs as $key => $value) : ?>
                <div class="form-group">
                    <label>
                        <span class="label-text"><?php echo $value['question']; ?></span>
                        <input type="hidden" name="faq[<?php echo $key; ?>][question]" value="<?php echo $value['question']; ?>">
                        <textarea name="faq[<?php echo $key; ?>][answer]" id="" cols="30" rows="2" placeholder="<?php echo $value['question']; ?>"><?php echo $value['answer']; ?></textarea>
                    </label>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <div class="form-group">
                <label>
                    <span class="label-text">What is SEO?</span>
                    <input type="hidden" name="faq[0][question]" value="What is SEO?">
                    <textarea name="faq[0][answer]" id="" cols="30" rows="2" placeholder="What is SEO?"></textarea>
                </label>
            </div>
            <div class="form-group">
                <label>
                    <span class="label-text">What types of websites do you specialize in designing?</span>
                    <input type="hidden" name="faq[1][question]" value="What types of websites do you specialize in designing?">
                    <textarea name="faq[1][answer]" id="" cols="30" rows="2" placeholder="What types of websites do you specialize in designing?"></textarea>
                </label>
            </div>
            <div class="form-group">
                <label>
                    <span class="label-text">What is the difference between a static and dynamic website?</span>
                    <input type="hidden" name="faq[2][question]" value="What is the difference between a static and dynamic website?">
                    <textarea name="faq[2][answer]" id="" cols="30" rows="2" placeholder="What is the difference between a static and dynamic website?"></textarea>
                </label>
            </div>
            <div class="form-group">
                <label>
                    <span class="label-text">Do you offer custom website designs or do you use templates?</span>
                    <input type="hidden" name="faq[3][question]" value="Do you offer custom website designs or do you use templates?">
                    <textarea name="faq[3][answer]" id="" cols="30" rows="2" placeholder="Do you offer custom website designs or do you use templates?"></textarea>
                </label>
            </div>
        <?php endif; ?>
    </div>

    <!-- Form Footer Actions -->
    <div class=" company-form-footer">
        <input type="hidden" name="action" value="save_company_faqs">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-company-form-prev btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn" data-step="6">Back</button>
            </div>
            <!-- <div class="col-auto">
<button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn">Cancel</button>
</div> -->
            <div class="col-auto">
                <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn">Next</button>
            </div>
        </div>
    </div>
</form>