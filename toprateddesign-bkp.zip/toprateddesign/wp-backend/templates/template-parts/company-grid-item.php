<?php

/**
 * Template part for displaying company grid item
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package wp-backend
 */

/*
<div class="col-12">
    <pre><?php print_r(get_post_meta(get_the_ID(), 'company_profile', true)); ?></pre>
    <pre><?php print_r(get_post_meta(get_the_ID(), 'company_services', true)); ?></pre>
    <pre><?php print_r(get_post_meta(get_the_ID(), 'company_sub_services', true)); ?></pre>
    <pre><?php print_r(get_post_meta(get_the_ID(), 'business_address', true)); ?></pre>
    <pre><?php print_r(get_post_meta(get_the_ID(), 'industry_focus', true)); ?></pre>
</div>
*/

$company_profile = json_decode(get_post_meta(get_the_ID(), 'company_profile', true));
// $company_profile = (array) $company_profile;

$company_services = json_decode(get_post_meta(get_the_ID(), 'company_services', true));
$company_services = (array) $company_services;
arsort($company_services);

$company_sub_services = json_decode(get_post_meta(get_the_ID(), 'company_sub_services', true));
$company_sub_services = (array) $company_sub_services;

$business_address = json_decode(get_post_meta(get_the_ID(), 'business_address', true));
// $business_address = (array) $business_address;

$industry_focus = json_decode(get_post_meta(get_the_ID(), 'industry_focus', true));
// $industry_focus = (array) $industry_focus;
?>

<div class="col-12">
    <div class="portfolio-inner">
        <div class="row">
            <div class="col-lg-3 col-md-4">
                <div class="company-logo">
                    <a href="#" class="open-profile">
                        <?php
                        if (has_post_thumbnail()) {
                            $featured_image = get_the_post_thumbnail_url(get_the_ID(), 'large');
                        } else {
                            $featured_image = 'https://topratedwebdesign.com/wp-content/uploads/2024/02/eseospace-logo-300x193.png';
                        }
                        ?>
                        <img decoding="async" src="<?php echo $featured_image; ?>" alt="<?php the_title(); ?>">
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-8">
                <div class="company-detail-wrapper">
                    <div class="company-title">
                        <h3>
                            <?php the_title(); ?>
                        </h3>
                    </div>
                    <div class="company-rating">
                        4.9 <small>(17 reviews)</small>
                    </div>
                    <div class="company-inner-texr">
                        <?php echo $company_profile->about_company; ?>
                    </div>
                    <div class="company-services">
                        <h4>Top Services</h4>
                        <ul class="company-services-list">
                            <?php
                            $company_services = array_slice($company_services, 0, 3);
                            foreach ($company_services as $key => $value) : ?>
                                <li><?php echo ucwords(str_replace('_', ' ', $key)); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-12 company-detail-container">
                <div class="company-contact-info">
                    <div class="company-cta">
                        <div class="custom-btn-wrapper">
                            <a href="<?php echo $company_profile->website; ?>" class="btn cstm-primary-btn cstm-primary-icon-btn" target="_blank">Visit Website</a>
                        </div>
                        <div class="custom-btn-wrapper">
                            <a href="<?php the_permalink(); ?>" class="btn cstm-primary-bordered-btn cstm-primary-icon-btn">Visit Portfolio</a>
                        </div>
                    </div>
                    <div class="company-about-info">
                        <ul class="about-info-list">
                            <!-- <li class="about-info-item company-location">San Diego, California</li> -->
                            <li class="about-info-item company-employees">
                                Under <?php echo $company_profile->employee_range; ?>
                            </li>
                            <li class="about-info-item company-salary-range">
                                <?php echo $company_profile->cost_per_hour; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>