jQuery(document).ready(function ($) {
	$(".submit-form-using-ajax").validate({
		errorPlacement: function (error, element) {
			if (element.attr("type") == "checkbox" || element.attr("type") == "radio") {
				error.insertAfter(element.closest("label"));
			} else {
				error.insertAfter(element);
			}
		},
	});

	// after wordpress ajax complete, validate form again
	$(document).ajaxComplete(function () {
		console.log("Ajax Complete");
		$(".submit-form-using-ajax").validate({
			errorPlacement: function (error, element) {
				if (element.attr("type") == "checkbox" || element.attr("type") == "radio") {
					error.insertAfter(element.closest("label"));
				} else {
					error.insertAfter(element);
				}
			},
		});
	});

	$(document).on("submit", ".submit-form-using-ajax", function (e) {
		e.preventDefault();
		$("body").LoadingOverlay("show");

		var form = $(this);
		var formData = new FormData(form[0]);
		$.ajax({
			type: "post",
			url: handler_object.ajax_url,
			contentType: false,
			processData: false,
			dataType: "json",
			data: formData,
		})
			.done(function (value) {
				if (value.success) {
					if (value.data.message) {
						Swal.fire({
							icon: "success",
							title: value.data.title || "Success",
							text: value.data.message,
						}).then((result) => {
							if (result.isConfirmed) {
								if (value.data.redirect) {
									window.location.href = value.data.redirect;
								}
							}
						});
					} else {
						if (value.data.redirect) {
							window.location.href = value.data.redirect;
						}
					}

					if (value.data.html) {
						$("#ajax-content").html(value.data.html);

						if ($("#ajax-content").length > 0) {
							$("html, body").animate(
								{
									scrollTop: $("#ajax-content").offset().top - 120,
								},
								1000
							);
						}
					}

					var action = formData.get("action");

					if (action) {
						$(document).trigger(action, [value, form]);
					}

					// form[0].reset();
				}
			})
			.fail(function (value) {
				$("body").LoadingOverlay("hide");
				Swal.fire({
					icon: "error",
					title: "Error",
					text: value.responseJSON.data.message,
				});
			})
			.always(function () {
				$("body").LoadingOverlay("hide");
			});
	});

	$(document).on("save_company_profile_data", function (e, value, form) {
		updateCompanyFormProgress(1);
	});

	$(document).on("save_company_services", function (e, value, form) {
		updateCompanyFormProgress(2);
	});

	$(document).on("save_company_business_address", function (e, value, form) {
		updateCompanyFormProgress(3);
	});

	$(document).on("save_industry_focus", function (e, value, form) {
		updateCompanyFormProgress(4);
	});

	$(document).on("invite_a_client_for_reviews", function (e, value, form) {
		updateCompanyFormProgress(5);
	});

	$(document).on("save_company_portfolio", function (e, value, form) {
		updateCompanyFormProgress(6);
	});

	$(document).on("save_company_faqs", function (e, value, form) {
		updateCompanyFormProgress(7);
	});

	$(document).on("update_user_password", function (e, value, form) {
		form[0].reset();
	});

	function updateCompanyFormProgress(step) {
		jQuery(".company-nav-menu .company-menu-item a").removeClass("active");
		jQuery(".company-nav-menu").find(".company-menu-item").eq(step).find("a").addClass("active");

		var width = (step / 7) * 90 + 10;
		jQuery(".company-creation-section .progress-bar .progress-bar-fill").css("width", width + "%");
	}

	$(document).on("click", ".add-portfolio", function (e) {
		e.preventDefault();

		var portfolioItem = $("[data-porfolio-row] [data-portfolio-item]").first().clone();
		portfolioItem.find('input[type="file"]').val("");
		portfolioItem.find("img").attr("src", "/wp-content/uploads/2024/03/Image-1.jpg");
		portfolioItem.find('input[type="text"], textarea, input[type="number"]').val("");
		portfolioItem.appendTo("[data-porfolio-row]");

		// update name indexes
		portfolioItem.find('input[type="file"]').attr("name", "portfolio[" + portfolioItem.index() + "][image]");
		portfolioItem.find('input[type="text"]').attr("name", "portfolio[" + portfolioItem.index() + "][project_name]");
		portfolioItem.find("textarea").attr("name", "portfolio[" + portfolioItem.index() + "][description]");
		portfolioItem.find('input[type="number"]').attr("name", "portfolio[" + portfolioItem.index() + "][budget]");

		portfolioItem.find(".portfolio-item").prepend(`
            <button type="button" class="btn btn-remove-portfolio">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="20" height="20">
                    <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
                </svg>
            </button>
        `);
	});

	$(document).on("click", ".btn-remove-portfolio", function (e) {
		e.preventDefault();
		$(this).closest("[data-portfolio-item]").remove();
	});

	// Company Form Prev Button Click Event
	$(document).on("click", ".btn-company-form-prev", function (e) {
		e.preventDefault();

		$("body").LoadingOverlay("show");

		var step = parseInt($(this).data("step"));

		$.ajax({
			type: "post",
			url: handler_object.ajax_url,
			dataType: "json",
			data: {
				action: "company_form_prev",
				step: step,
			},
		})
			.done(function (value) {
				if (value.success) {
					$("#ajax-content").html(value.data.html);
					updateCompanyFormProgress(step - 1);
				}
			})
			.fail(function (value) {
				Swal.fire({
					icon: "error",
					title: "Error",
					text: value.responseJSON.data.message,
				});
			})
			.always(function () {
				$("body").LoadingOverlay("hide");
			});
	});

	// Company Form Specific Step Click Event
	$(document).on("click", ".company-nav-menu .company-menu-item a", function (e) {
		e.preventDefault();

		$("body").LoadingOverlay("show");

		var step = parseInt($(this).data("step"));

		$.ajax({
			type: "post",
			url: handler_object.ajax_url,
			dataType: "json",
			data: {
				action: "company_form_specific_step",
				step: step,
			},
		})
			.done(function (value) {
				if (value.success) {
					$("#ajax-content").html(value.data.html);
					updateCompanyFormProgress(step - 1);
				}
			})
			.fail(function (value) {
				Swal.fire({
					icon: "error",
					title: "Error",
					text: value.responseJSON.data.message,
				});
			})
			.always(function () {
				$("body").LoadingOverlay("hide");
			});
	});

	$(document).on("change", ".image-file-selector input", function () {
		var input = $(this);
		var img = input.parent().find("img");
		var file = input[0].files[0];
		var reader = new FileReader();
		reader.onload = function (e) {
			img.attr("src", e.target.result);
		};
		reader.readAsDataURL(file);
	});

	// document ready end
}); // jQuery(document).ready(function($)
