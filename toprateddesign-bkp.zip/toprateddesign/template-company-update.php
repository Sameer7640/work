<?php
// Template Name: Update Company

if (!is_user_logged_in()) {
    wp_redirect(site_url('/login'));
    exit;
}

get_header();

$user = wp_get_current_user();
$post_id = $user->company_id;
$company_data = get_post_meta($post_id, 'company_profile', true);
if ($company_data) {
    $company_data = json_decode($company_data, true);
} else {
    $company_data = array();
}

$company_services = get_post_meta($post_id, 'company_services', true);
if ($company_services) {
    $company_services = json_decode($company_services, true);
} else {
    $company_services = array();
}

$company_sub_services_list = get_post_meta($post_id, 'company_sub_services', true);
if ($company_sub_services_list) {
    $company_sub_services_list = json_decode($company_sub_services_list, true);
} else {
    $company_sub_services_list = array();
}

$business_address = get_post_meta($post_id, 'business_address', true);
if ($business_address) {
    $business_address = json_decode($business_address, true);
} else {
    $business_address = array();
}

$industry_focus = get_post_meta($post_id, 'industry_focus', true);
if ($industry_focus) {
    $industry_focus = json_decode($industry_focus, true);
} else {
    $industry_focus = array();
}

global $wpdb;
$company_id = wp_get_current_user()->company_id;
$employees = $wpdb->get_results("SELECT * FROM company_employees WHERE company_id = $company_id", ARRAY_A);
$faqs = $wpdb->get_results("SELECT * FROM company_faqs WHERE company_id = $company_id", ARRAY_A);
$portfolio = $wpdb->get_results("SELECT * FROM company_portfolios WHERE company_id = $company_id", ARRAY_A);
?>


<style>
    .company-creation-section .company-form-content.collapsed-section .company-form-inner-section {
        display: none;
    }

    .company-creation-section .company-form-content.collapsed-section .form-save-btn,
    .company-creation-section .company-form-content .form-edit-btn {
        display: none;
    }

    .company-creation-section .company-form-content.collapsed-section .form-edit-btn {
        display: block;
    }
</style>

<div class="col-12">
    <section class="company-creation-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- My Account -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">My Account</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="update_account_details">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">First Name *</span>
                                            <input type="text" name="first_name" placeholder="First Name" value="<?php echo $user->first_name ? $user->first_name : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Last Name *</span>
                                            <input type="text" name="last_name" placeholder="Last Name" value="<?php echo $user->last_name ? $user->last_name : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Email *</span>
                                            <input type="email" name="email" placeholder="Email" value="<?php echo $user->user_email ? $user->user_email : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Phone Number *</span>
                                            <input type="text" name="phone_number" placeholder="Phone Number" value="<?php echo array_key_exists('phone_number', $company_data) ? $company_data['phone_number'] : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Company Name</span>
                                            <input type="text" name="company_name" placeholder="Company Name" value="<?php echo array_key_exists('company_name', $company_data) ? $company_data['company_name'] : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Designation</span>
                                            <input type="text" name="designation" placeholder="Designation *" value="<?php echo array_key_exists('designation', $company_data) ? $company_data['designation'] : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- My Account -->

                    <!-- Change Password -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Change Password</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="update_user_password">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <div class="row">
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Old Password *</span>
                                            <input type="password" name="current_password" placeholder="Type Old Password">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">New Password *</span>
                                            <input type="password" name="new_password" placeholder="Type New Password">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Confirm Password *</span>
                                            <input type="password" name="confirm_password" placeholder="Type Confirm Password">
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Company Profile -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Company Profile</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="save_company_profile_data">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="image-file-selector">
                                        <input type="file" name="company_profile_image">
                                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/03/Image-1.jpg" alt="">
                                        <span class="label-text">
                                            Upload Logo *
                                        </span>
                                    </label>
                                </div>
                                <div class="col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Company Name *</span>
                                                    <input type="text" placeholder="Company Name" name="company_name" value="<?php echo array_key_exists('company_name', $company_data) ? $company_data['company_name'] : ''; ?>" required>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Year Founded *</span>
                                                    <select name="year_found" required>
                                                        <option value="">Year Founded</option>
                                                        <?php for ($i = 2022; $i >= 1900; $i--) : ?>
                                                            <option value="<?php echo $i; ?>" <?php echo array_key_exists('year_found', $company_data) && $company_data['year_found'] == $i ? 'selected' : ''; ?>>
                                                                <?php echo $i; ?>
                                                            </option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Tag Line *</span>
                                                    <input type="text" placeholder="Top Rated Web Design & Development" name="tag_line" value="<?php echo array_key_exists('tag_line', $company_data) ? $company_data['tag_line'] : ''; ?>" required>
                                                </label>
                                            </div>
                                        </div>
                                        <div class=" col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Email *</span>
                                                    <input type="email" placeholder="Email" name="email" value="<?php echo array_key_exists('email', $company_data) ? $company_data['email'] : ''; ?>" required>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Min. Project Amount*</span>
                                                    <select name="min_project_amount" required>
                                                        <option value="">Min. Project Amount</option>
                                                        <?php for ($i = 500; $i <= 10000; $i += 500) : ?>
                                                            <option value="<?php echo $i . '-' . ($i + 500); ?>" <?php echo array_key_exists('min_project_amount', $company_data) && $company_data['min_project_amount'] == $i . '-' . ($i + 500) ? 'selected' : ''; ?>>
                                                                <?php echo $i . '-' . ($i + 500); ?>
                                                            </option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Website *</span>
                                                    <input type="text" placeholder="Website" name="website" value="<?php echo array_key_exists('website', $company_data) ? $company_data['website'] : ''; ?>" required>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Phone Number *</span>
                                                    <input type="text" placeholder="Phone Number" name="phone_number" value="<?php echo array_key_exists('phone_number', $company_data) ? $company_data['phone_number'] : ''; ?>" required>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">About Company *</span>
                                            <textarea name="about_company" id="" cols="30" rows="4" placeholder="About Company" required><?php echo array_key_exists('about_company', $company_data) ? $company_data['about_company'] : ''; ?></textarea>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <h4 class="mt-5">Cost Per Hour & Employee Range</h4>
                            <hr>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Cost Per Hour *</span>
                                            <select name="cost_per_hour" required>
                                                <option value="">Cost Per Hour</option>
                                                <?php for ($i = 0; $i <= 250; $i += 50) : ?>
                                                    <option value="<?php echo '$' . $i . ' - $' . ($i + 50); ?>" <?php echo array_key_exists('cost_per_hour', $company_data) && $company_data['cost_per_hour'] == '$' . $i . ' - $' . ($i + 50) ? 'selected' : ''; ?>>
                                                        <?php echo '$' . $i . ' - $' . ($i + 50); ?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Employee Range *</span>
                                            <select name="employee_range" required>
                                                <option value="">Employee Range</option>
                                                <?php for ($i = 0; $i <= 500; $i += 50) : ?>
                                                    <option value="<?php echo $i . ' - ' . ($i + 50); ?>" <?php echo array_key_exists('employee_range', $company_data) && $company_data['employee_range'] == $i . ' - ' . ($i + 50) ? 'selected' : ''; ?>>
                                                        <?php echo $i . ' - ' . ($i + 50); ?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <h4 class="mt-5">Social Connections</h4>
                            <hr>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Facebook</span>
                                            <input type="url" placeholder="Facebook URL" name="facebook" value="<?php echo array_key_exists('facebook', $company_data) ? $company_data['facebook'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Twitter</span>
                                            <input type="url" placeholder="Twitter URL" name="twitter" value="<?php echo array_key_exists('twitter', $company_data) ? $company_data['twitter'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Linkedin</span>
                                            <input type="url" placeholder="Linkedin URL" name="linkedin" value="<?php echo array_key_exists('linkedin', $company_data) ? $company_data['linkedin'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class=" col-lg-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">YouTube Channel</span>
                                            <input type="url" placeholder="Youtube URL" name="youtube" value="<?php echo array_key_exists('youtube', $company_data) ? $company_data['youtube'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Company Profile -->

                    <!-- Company Services -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Services</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <nav class="mb-4">
                                <div class="nav company-form-tabs" id="nav-tab" role="tablist">
                                    <a class="active" id="company-services-tab-title" data-toggle="tab" href="#company-services-tab" role="tab" aria-controls="company-services-tab" aria-selected="true">
                                        <h4 class="mb-0">
                                            Company Services
                                        </h4>
                                    </a>
                                    <a id="company-sub-services-tab-title" data-toggle="tab" href="#company-sub-services" role="tab" aria-controls="company-sub-services" aria-selected="false">
                                        <h4 class="mb-0">
                                            Company Sub Services
                                        </h4>
                                    </a>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="company-services-tab" role="tabpanel" aria-labelledby="company-services-tab-title">
                                    <div class="row">
                                        <?php

                                        $services = array(
                                            'Artificial Intelligence',
                                            'Big Data Analytics',
                                            'Blockchain',
                                            'Branding',
                                            'Cloud Computing',
                                            'Cybersecurity',
                                            'Digital Marketing',
                                            'Ecommerce Development',
                                            'Enterprise Resource Planning',
                                            'Game Development',
                                            'IT Services',
                                            'Metaverse',
                                            'Mobile App Development',
                                            'PR Firms',
                                            'Testing',
                                            'Translation Servies',
                                            'UI/UX Designing',
                                            'Video Production',
                                            'Wearable App Development',
                                            'Web and Software Development',
                                            'Business'
                                        );
                                        ?>

                                        <?php foreach ($services as $service) : ?>
                                            <?php
                                            $strip_special_characters = preg_replace('/[^A-Za-z0-9\s\-]/', '', $service);
                                            $strip_special_characters = rtrim($strip_special_characters);
                                            $strip_special_characters = preg_replace('/\s+/', ' ', $strip_special_characters);

                                            $service_item_percentage = strtolower(str_replace(' ', '_', $strip_special_characters));
                                            ?>
                                            <div class="col-md-6 col-lg-4">
                                                <div class="form-group">
                                                    <label>
                                                        <span class="label-text"><?php echo $service; ?></span>
                                                        <input type="number" placeholder="0" name="<?php echo $service_item_percentage; ?>" value="<?php echo array_key_exists($service_item_percentage, $company_services) ? $company_services[$service_item_percentage] : 0; ?>">
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="company-sub-services" role="tabpanel" aria-labelledby="company-sub-services-tab-title">
                                    <?php
                                    $company_sub_services =
                                        array(
                                            'Mobile App Development' => array(
                                                'Swift',
                                                'Internet Of Things',
                                                'Hybrid',
                                                'Enterprise App',
                                                'Augmented Reality',
                                                'Virtual Reality',
                                                'React Native',
                                                'Flutter',
                                                'App Design',
                                                'Android App',
                                                'iPhone App',
                                                'iPad Design'
                                            ),
                                            'Framework and CMS' => array(
                                                '.NET',
                                                'Adobe',
                                                'Cake PHP',
                                                'Codeigniter',
                                                'Django',
                                                'DNN (DotNetDuke)',
                                                'Drupal',
                                                'Ektron',
                                                'Expression Engine',
                                                'HP',
                                                'IBM',
                                                'Joomla',
                                                'Laravel',
                                                'Oracle',
                                                'Ruby on Rails',
                                                'SDL',
                                                'Microsoft SharePoint',
                                                'Sitecore',
                                                'Spring MVC',
                                                'Struts',
                                                'Symfony',
                                                'WordPress',
                                                'Zend',
                                                'Zope',
                                                'Other frameworks and CMs',
                                                'Yii',
                                                'MEAN Stack',
                                                'MERN Stack',
                                                'Full Stack Developers',
                                                'Back End Developers',
                                                'Front End Developers',
                                                'WordPress Web Design',
                                                'DevOps Developers'
                                            ),
                                            'Programming ang Scripting' => array(
                                                'AJAX',
                                                'Apex',
                                                'ASP',
                                                'ASP.NET',
                                                'C',
                                                'C#',
                                                'C++',
                                                'Cold Fusion',
                                                'Delphi',
                                                'Java',
                                                'JavaScript',
                                                'Objective C',
                                                'Perl',
                                                'PHP',
                                                'Python',
                                                'Ruby',
                                                'SQL',
                                                'Virtual Basic',
                                                'XML',
                                                'Other Programming & Scripting Languages',
                                                'Angular JS',
                                                'NodeJS',
                                                'React JS',
                                                'Vue JS '
                                            ),
                                            'Web and Software Development' => array(
                                                'Web Development',
                                                'Software Development',
                                                'Progressive Web App (PWA)',
                                                'Web Design',
                                            ),
                                        );

                                    foreach ($company_sub_services as $key => $value) : ?>
                                        <div class="row">
                                            <div class="col-12">
                                                <h4><?php echo $key; ?></h4>
                                                <div class="row">
                                                    <?php foreach ($value as $key => $sub_service) : ?>
                                                        <?php
                                                        $strip_special_characters = preg_replace('/[^A-Za-z0-9\s\-]/', '', $sub_service);
                                                        $strip_special_characters = rtrim($strip_special_characters);
                                                        $strip_special_characters = preg_replace('/\s+/', ' ', $strip_special_characters);

                                                        $service_item = strtolower(str_replace(' ', '_', $strip_special_characters));
                                                        ?>
                                                        <div class="col-md-6 col-lg-4">
                                                            <div class="checkbox-group">
                                                                <label>
                                                                    <input type="checkbox" name="company_sub_services[]" value="<?php echo $service_item; ?>" <?php echo in_array($service_item, $company_sub_services_list) ? 'checked' : ''; ?>>
                                                                    <span class="label-text"><?php echo $sub_service; ?></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                                <hr>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Company Services -->

                    <!-- Business Address -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Business Address</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="save_business_address">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Address Line 1 *</span>
                                            <input type="text" name="business_address_line_1" placeholder="Description Here" value="<?php echo array_key_exists('business_address_line_1', $business_address) ? $business_address['business_address_line_1'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Address Line 2</span>
                                            <input type="text" name="business_address_line_2" placeholder="Description Here" value="<?php echo array_key_exists('business_address_line_2', $business_address) ? $business_address['business_address_line_2'] : ''; ?>">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">State *</span>
                                            <input type="text" name="business_state" placeholder="Select State" value="<?php echo array_key_exists('business_state', $business_address) ? $business_address['business_state'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">City</span>
                                            <input type="text" name="business_city" placeholder="Select Country" value="<?php echo array_key_exists('business_address_line_2', $business_address) ? $business_address['business_address_line_2'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Zip Code *</span>
                                            <input type="text" name="business_zip_code" placeholder="Zip Code" value="<?php echo array_key_exists('business_zip_code', $business_address) ? $business_address['business_zip_code'] : ''; ?>" required>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Business Address -->

                    <!-- Industry Focus -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Industry Focus</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="save_industry_focus">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <div class="row">
                                <?php
                                $industry_focus_array = array(
                                    'Advertising & Marketing (%)',
                                    'Automotive (%)',
                                    'Art. Entertainment & Music (%)',
                                    'Business Services (%)',
                                    'Consumer Products & Services (%)',
                                    'Education (%)',
                                    'Financial & Payments (%)',
                                    'Gaming (%)',
                                    'Government (% )',
                                    'Healthcare & Life Insurance (%)',
                                    'Hospitality &   Leisure (%)',
                                    'Information Technology (%)',
                                    'Telecommunications (%)',
                                    'Legal Compliance (%)',
                                    'Manufacturing (%)',
                                    'Media (%)',
                                    'Real Estate (%)',
                                    'Transportation & Logistics (%)',
                                    'Utilities (%)',
                                    'Retail (%)',
                                    'Other Industries (%)',
                                    'Energy & Natural Resources (%)',
                                    'Non-Profit (%)'
                                ); ?>

                                <?php foreach ($industry_focus_array as $industry) : ?>
                                    <?php
                                    $industry = strtolower(str_replace('-', ' ', $industry));
                                    $strip_special_characters = preg_replace('/[^A-Za-z0-9\s\-]/', '', $industry);
                                    $strip_special_characters = rtrim($strip_special_characters);
                                    $strip_special_characters = preg_replace('/\s+/', ' ', $strip_special_characters);

                                    $industry_item = strtolower(str_replace(' ', '_', $strip_special_characters));
                                    ?>

                                    <div class="col-md-6 col-lg-4">
                                        <div class="form-group">
                                            <label>
                                                <span class="label-text"><?php echo $industry; ?></span>
                                                <input type="number" placeholder="0" name="<?php echo $industry_item; ?>" value="<?php echo array_key_exists($industry_item, $industry_focus) ? $industry_focus[$industry_item] : ''; ?>">
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </form>
                    <!-- Industry Focus -->

                    <!-- Reviews -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Reviews</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="invite_a_client_for_reviews">
                                <button type=" submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <p>You have not received any reviews yet.</p>
                            <div class="row align-items-end">
                                <div class="col-12 col-md">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Customer Email</span>
                                            <input type="email" placeholder="Customer Email" name="invite_email">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 col-md-auto">
                                    <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3">Invite</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Reviews -->

                    <!-- Portfolio -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">Portflio</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="save_company_portfolio">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <button class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3 add-portfolio">Add
                                Portfolio
                            </button>
                            <div class="row" data-porfolio-row>
                                <?php
                                if ($portfolio) :
                                    foreach ($portfolio as $key => $value) : ?>
                                        <div class="col-md-6 col-lg-4" data-portfolio-item>
                                            <div class="portfolio-item">
                                                <?php if ($key != 0) : ?>
                                                    <button type="button" class="btn btn-remove-portfolio">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="20" height="20">
                                                            <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"></path>
                                                        </svg>
                                                    </button>
                                                <?php endif; ?>
                                                <div class="form-group">
                                                    <label class="image-file-selector">
                                                        <input type="file" name="portfolio[0][image]">
                                                        <img src="<?php echo $value['image'] ? $value['image'] : site_url() . '/wp-content/uploads/2024/03/Image-1.jpg'; ?>" alt="">
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>
                                                        <span class="label-text">Project Name</span>
                                                        <input type="text" placeholder="Project Name" name="portfolio[0][project_name]" value="<?php echo $value['name']; ?>">
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>
                                                        <span class="label-text">Description</span>
                                                        <textarea name="portfolio[0][description]" id="" cols="30" rows="2" placeholder="Description"><?php echo $value['description']; ?></textarea>
                                                    </label>
                                                </div>
                                                <div class="form-group">
                                                    <label>
                                                        <span class="label-text">Budget</span>
                                                        <input type="number" placeholder="Budget" name="portfolio[0][budget]" value="<?php echo $value['budget']; ?>">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach;
                                else : ?>
                                    <div class="col-md-6 col-lg-4" data-portfolio-item>
                                        <div class="portfolio-item">
                                            <div class="form-group">
                                                <label class="image-file-selector">
                                                    <input type="file" name="portfolio[0][image]">
                                                    <img src="<?php echo site_url() . '/wp-content/uploads/2024/03/Image-1.jpg'; ?>" alt="">
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Project Name</span>
                                                    <input type="text" placeholder="Project Name" name="portfolio[0][project_name]">
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Description</span>
                                                    <textarea name="portfolio[0][description]" id="" cols="30" rows="2" placeholder="Description"></textarea>
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <span class="label-text">Budget</span>
                                                    <input type="number" placeholder="Budget" name="portfolio[0][budget]">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                    <!-- Portfolio -->

                    <!-- Faqs -->
                    <form class="company-form-content collapsed-section submit-form-using-ajax">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="mb-0">FAQS</h4>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-edit-btn">
                                    Edit
                                </button>
                                <input type="hidden" name="action" value="save_company_faqs">
                                <button type="submit" class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn form-save-btn">
                                    Save All
                                </button>
                            </div>
                        </div>
                        <div class="company-form-inner-section">
                            <hr>
                            <?php if ($faqs) : ?>
                                <?php foreach ($faqs as $key => $value) : ?>
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text"><?php echo $value['question']; ?></span>
                                            <input type="hidden" name="faq[<?php echo $key; ?>][question]" value="<?php echo $value['question']; ?>">
                                            <textarea name="faq[<?php echo $key; ?>][answer]" id="" cols="30" rows="2" placeholder="<?php echo $value['question']; ?>"><?php echo $value['answer']; ?></textarea>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <div class="form-group">
                                    <label>
                                        <span class="label-text">What is SEO?</span>
                                        <input type="hidden" name="faq[0][question]" value="What is SEO?">
                                        <textarea name="faq[0][answer]" id="" cols="30" rows="2" placeholder="What is SEO?"></textarea>
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <span class="label-text">What types of websites do you specialize in designing?</span>
                                        <input type="hidden" name="faq[1][question]" value="What types of websites do you specialize in designing?">
                                        <textarea name="faq[1][answer]" id="" cols="30" rows="2" placeholder="What types of websites do you specialize in designing?"></textarea>
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <span class="label-text">What is the difference between a static and dynamic website?</span>
                                        <input type="hidden" name="faq[2][question]" value="What is the difference between a static and dynamic website?">
                                        <textarea name="faq[2][answer]" id="" cols="30" rows="2" placeholder="What is the difference between a static and dynamic website?"></textarea>
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label>
                                        <span class="label-text">Do you offer custom website designs or do you use templates?</span>
                                        <input type="hidden" name="faq[3][question]" value="Do you offer custom website designs or do you use templates?">
                                        <textarea name="faq[3][answer]" id="" cols="30" rows="2" placeholder="Do you offer custom website designs or do you use templates?"></textarea>
                                    </label>
                                </div>
                            <?php endif; ?>
                        </div>
                    </form>
                    <!-- Faqs -->
                </div>
            </div>
        </div>
    </section>

    <div class="mfp-hide popup-review">
        <section class="mfp-with-anim dashboard-popup">
            <div class="row">
                <div class="col-md-12">
                    <div class="modal-body">
                        <h3 class="modal-title">Portfolio</h3>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">
                                <label class="image-file-selector mb-md-0   ">
                                    <input type="file" name="company_profile_image">
                                    <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/03/Image-1.jpg" alt="">
                                    <span class="label-text">
                                        Upload Logo *
                                    </span>
                                </label>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <span class="label-text">Title *</span>
                                    <input type="text" placeholder="Title" name="portfolio_title">
                                </div>
                                <div class="form-group">
                                    <span class="label-text">Portfolio URL *</span>
                                    <input type="text" placeholder="Portfolio URL" name="portfolio_url">
                                </div>
                                <div class="form-group">
                                    <span class="label-text">Project Description *</span>
                                    <textarea name="portfolio_description" cols="30" rows="4" placeholder="Description"></textarea>
                                </div>
                                <div class="text-right">
                                    <button class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <script type="text/javascript">
        jQuery(document).ready(function($) {

            jQuery(document).on('click', '.open-portfolio-add-modal', function(event) {
                event.preventDefault();

                jQuery(this).magnificPopup({
                    items: {
                        src: '.popup-review',
                        type: 'inline'
                    },
                    fixedContentPos: true,
                    callbacks: {
                        beforeOpen: function() {
                            jQuery('html').addClass('mfp-helper');
                        },
                        close: function() {
                            jQuery('html').removeClass('mfp-helper');
                        }
                    }
                }).magnificPopup('open');

            }); //click ends here
        });
    </script>
</div>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function($) {
        jQuery('.company-form-content').each(function() {
            jQuery(this).find('.form-edit-btn').click(function() {
                jQuery('.company-form-content').addClass('collapsed-section');
                jQuery(this).closest('.company-form-content').toggleClass('collapsed-section');
                jQuery('html, body').animate({
                    scrollTop: jQuery(this).closest('.company-form-content').offset().top - 120
                }, 300);
            });
        });
    });
</script>