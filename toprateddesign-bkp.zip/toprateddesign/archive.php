<?php
/* Template Name: Blog Page */
get_header(); 
?>
<style>
    #blog-posts>div:first-child {
        display: none !important;
    }
	#custom-blog-page img {
		width: 100% !important;
	}
	#blog-page-title {
		padding: 90px 0 !important;
	}
	#blog-page-title .breadcrumb-txt {
		color: #1E1E1E;
		font-family: 'Inter' !important;
		font-weight: 600 !important;
		font-size: 16px;
	}
	#blog-page-title .breadcrumb-txt>span {
		opacity: 0.5;
	}
	#blog-page-title .page-titlee {
		font-family: 'Inter' !important;
		font-weight: 700 !important;
		text-transform: capitalize !important;
		font-size: 55px !important;
		line-height: 65px !important;
		color: black;
		margin: 0;
		letter-spacing: -2px !important;
	}
	.cstm-featured-blog-post .cstm-post-content .post-meta .author-avatar img {
		height: 50px;
		width: 50px;
		object-fit: cover !important;
		border-radius: 50%;
	}
	.cstm-featured-blog-post {
		position: relative;
	}
	.cstm-featured-blog-post .cstm-post-content {
		position: absolute !important;
		top: 0 !important;
		left: 0;
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		padding: 30px;
		background-image: url('/wp-content/uploads/2024/05/Rectangle-2665.png');
		background-position: bottom center;
		background-repeat: no-repeat;
		background-size: 100%;
	}
	.cstm-featured-blog-post .cstm-post-content .post-meta {
		display: flex;
		align-items: center;
	}
	.cstm-featured-blog-post .cstm-post-content .post-meta .author-avatar {
		margin-right: 10px;
	}
	.cstm-featured-blog-post .cstm-post-content p {
		margin: 0;
		color: #fff;
	}
	.cstm-featured-blog-post .cstm-post-content .post-author {
		font-family: 'Inter' !important;
		font-weight: 400 !important;
		font-size: 14px;
		text-transform: capitalize;
		line-height: 24px;
	}
	.cstm-featured-blog-post .cstm-post-content .post-date {
		color: #C1C1C1;
		font-family: 'Inter' !important;
		font-weight: 300;
		font-size: 10px;
		line-height: 13px;
	}
	.cstm-featured-blog-post .cstm-post-content h2 a {
		color: #fff;
	}
	.cstm-featured-blog-post .cstm-post-content h2 {
		font-family: 'Inter' !important;
		font-weight: 700 !important;
		font-size: 42px;
		line-height: 52px !important;
		margin-right: 10%;
	}
	#featured-blog>.col-md-8 .column-wrapper {
		border-right: 1px solid #BCC7D5;
		padding-right: 35px;
	}
	#featured-blog .popular-post-title h2 {
		color: #788492 !important;
		font-family: 'Inter' !important;
		font-size: 32px !important;
		line-height: 42px !important;
		font-weight: 700 !important;
		margin: 0 !important;
	}
	#featured-blog .popular-post-title {
		margin-bottom: 20px;
	}
	#featured-blog .cstm-popular-posts>.cstm-featured-popular-post:not(:last-child) {
		margin-bottom: 20px;
	}
	#featured-blog .cstm-popular-posts>.cstm-featured-popular-post h3 {
		font-family: 'Inter' !important;
		font-weight: 700 !important;
		font-size: 22px !important;
		margin-bottom: 5px !important;
	}
	#featured-blog .cstm-popular-posts>.cstm-featured-popular-post h3 a {
		color: black !important;
	}
	#featured-blog .cstm-popular-posts>.cstm-featured-popular-post .post-meta {
		color: #788492 !important;
		font-family: 'Inter' !important;
		font-weight: 400;
		font-size: 12px;
	}
	#featured-blog {
		padding-bottom: 100px !important;
	}
	#blog-posts .blog-post {
		border-radius: 16px;
		border: 1px solid #E4EAF1;
		padding: 13px !important;
	}
	#blog-posts .blog-post .post-meta {
		margin-top: 20px;
		color: #788492 !important;
		font-family: 'Inter' !important;
		font-weight: 400;
		font-size: 12px;
		margin-bottom: 4px;
	}
	#blog-posts .blog-post h2 {
		margin: 0 !important;
		font-family: Inter;
		font-size: 20px;
		font-weight: 600;
		line-height: 130%;
		letter-spacing: -0.96px;
		margin-right: 20% !important;
	}
	#blog-posts .blog-post h2 a {
		color: black !important;
		text-shadow: 0 0 black;
	}
	#blog-posts>div {
		margin-bottom: 30px;
	}
	#custom-blog-page button#load-more {
		margin: 0 auto;
		display: table;
		color: #000;
		text-align: center;
		font-family: Inter;
		font-size: 16.594px;
		text-transform: capitalize !important;
		background-color: #fff0 !important;
		padding: 15px 35px;
		border-radius: 500px;
		border: 2px solid #000;
	}
	#blog-posts .blog-post img {
		height: 270px;
		object-fit: cover;
	}
	#custom-blog-page {
		padding-bottom: 100px;
	}
	#custom-blog-page #blog-posts {
		margin-bottom: 20px;
	}
	#featured-blog .cstm-featured-blog-post>a> img {
		height: 480px;
		object-fit: cover !important;
	}
	.cstm-featured-blog-post .cstm-post-content h2 {
		text-shadow: 2px 2px 8px #000;
	}
	@media (max-width: 1440px) {
		#custom-blog-page {
			padding-left: 4%;
			padding-right: 4%;
		}
		.cstm-featured-blog-post .cstm-post-content h2 {
			font-size: 38px !important;
			line-height: 48px !important;
		}
		#blog-page-title .page-titlee {
			font-size: 50px !important;
			line-height: 60px !important;
		}
		#blog-posts .blog-post img {
			height: 240px;
		}
	}
	@media (max-width: 1366px) {
		#featured-blog .cstm-popular-posts>.cstm-featured-popular-post h3 {
			font-size: 18px !important;
			line-height: 28px !important;
		}
		#featured-blog .cstm-featured-blog-post>a> img {
			height: 460px;
		}
	}
	@media (max-width: 1024px) {
		#blog-page-title .page-titlee {
			font-size: 40px !important;
			line-height: 50px !important;
		}
		#blog-page-title {
			padding: 60px 0 !important;
		}
		#blog-page-title .breadcrumb-txt {
			font-size: 14px !important;
			line-height: 24px !important;
		}
		.cstm-featured-blog-post .cstm-post-content h2 {
			font-size: 28px !important;
			line-height: 38px !important;
		}
		#featured-blog .popular-post-title h2 {
			font-size: 22px !important;
			line-height: 22px !important;
		}
		#featured-blog .cstm-popular-posts>.cstm-featured-popular-post h3 {
			font-size: 14px !important;
			line-height: 24px !important;
			margin-bottom: 0 !important;
		}
		#featured-blog .cstm-popular-posts>.cstm-featured-popular-post:not(:last-child) {
			margin-bottom: 7px !important;
		}
		.cstm-featured-blog-post .cstm-post-content {
			padding: 20px !important;
		}
		#featured-blog {
			padding-bottom: 60px !important;
		}
		#custom-blog-page {
			padding-bottom: 60px !important;
		}
		#custom-blog-page #blog-posts {
			margin-bottom: 0 !important;
		}
		#blog-posts .blog-post h2 {
			font-size: 16px !important;
			line-height: 26px !important;
		}
		#blog-posts .blog-post img {
			height: 180px;
		}
		#custom-blog-page button#load-more {
			font-size: 14px !important;
			padding: 13px 30px !important;
		}
		#featured-blog .cstm-featured-blog-post>a> img {
			height: 350px;
		}
	}
	@media (max-width: 820px) {
		#blog-page-title .page-titlee {
			font-size: 35px !important;
			line-height: 45px !important;
		}
		#featured-blog>.col-md-8 .column-wrapper {
			border: none !important;
			padding: 0 !important;
		}
		#featured-blog>div {
			width: 100% !important;
			max-width: 100% !important;
			flex: unset !important;
		}
		#featured-blog>div:not(:last-child) {
			margin-bottom: 40px;
		}
		#featured-blog {
			padding-bottom: 40px !important;
		}
		#custom-blog-page {
			padding-bottom: 40px !important;
		}
		#blog-posts .blog-post h2 {
			margin-right: 0 !important;
			font-size: 14px !important;
			line-height: 24px !important;
		}
		#custom-blog-page button#load-more {
			padding: 10px 30px !important;
		}
		#blog-posts .blog-post img {
			height: 140px;
		}
		#featured-blog .cstm-featured-blog-post>a> img {
			height: 450px;
		}
	}
	@media (max-width: 767px) {
		#custom-blog-page #blog-posts>div {
			width: 50% !important;
		}
		#blog-posts .blog-post img {
			height: 200px !important;
		}
	}
	@media (max-width: 480px) {
		#blog-page-title {
			padding: 40px 0 !important;
		}
		#blog-page-title .page-titlee {
			font-size: 28px !important;
			line-height: 38px !important;
		}
		#blog-page-title .breadcrumb-txt {
			margin-bottom: 5px;
		}
		.cstm-featured-blog-post .cstm-post-content h2 {
			font-size: 20px !important;
			line-height: 30px !important;
			text-shadow: 4px 4px 8px #000;
			margin: 0 0 10px 0;
		}
		.cstm-featured-blog-post .cstm-post-content .post-meta .author-avatar img {
			width: 30px !important;
			height: 30px !important;
		}
		.cstm-featured-blog-post .cstm-post-content {
			padding: 10px !important;
		}
		#custom-blog-page #blog-posts>div {
			width: 100% !important;
			margin-bottom: 20px;
		}
		#blog-posts .blog-post img {
			height: 250px !important;
		}
		#featured-blog .cstm-featured-blog-post>a> img {
			height: 310px;
		}
	}
	@media (max-width: 414px) {
		#blog-page-title .page-titlee {
			font-size: 26px !important;
			line-height: 36px !important;
		}
		#featured-blog .cstm-featured-blog-post>a> img {
			height: 240px;
		}
	}
</style>
<div id="custom-blog-page" class="content-area">
    <main id="main" class="site-main">
        <div id="blog-page-title">
            <p class="breadcrumb-txt"><span style="color: #1E1E1E;"><a style="color: #1E1E1E;" href="https://topratedwebdesign.com/">Home</a> > </span>Reviews</p>
            <h1 class="page-titlee">Insights Hub: Dive into Our <br>Blog for <span style="color: #30D4DE;">Expert Perspectives</span></h1>
        </div>
        <div id="featured-blog" class="row">
            <div class="col-md-8">
                <div class="column-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                    'posts_per_page' => 1 
                    );

                    $query = new WP_Query($args);

                    if ($query->have_posts()) :
                        while ($query->have_posts()) : $query->the_post();
                            ?>
                            <div class="cstm-featured-blog-post">
                                <?php if (has_post_thumbnail()) : ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('full'); ?>
                                    </a>
                                <?php endif; ?>
                                <div class="cstm-post-content">
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <div class="post-meta">
										<div class="author-avatar">
											<?php
												// Display author avatar
												$author_id = get_the_author_meta('ID');
												echo get_avatar($author_id, 32); 
											?>
										</div>
										<div class="post-meta-txt">
                                        	<p class="post-author"><?php the_author(); ?></p>
                                        	<p class="post-date"><?php echo get_the_date(); ?></p>
										</div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                    else :
                        echo 'No posts found.';
                    endif;
                    ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="column-wrapper">
                    <div class="popular-post-title">
                        <h2>Popular Posts</h2>
                    </div>
                    <div class="cstm-popular-posts">
                        <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 4 
                        );

                        $query = new WP_Query($args);

                        if ($query->have_posts()) :
                            while ($query->have_posts()) : $query->the_post();
                                ?>
                                <div class="cstm-featured-popular-post">
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <div class="post-meta">
                                        <span class="post-date"><?php echo get_the_date(); ?></span>
                                        <span class="post-author">By <?php the_author(); ?></span>
                                    </div>
                                </div>
                                <?php
                            endwhile;
                        else :
                            echo 'No posts found.';
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div id="blog-posts" class="row">
            <?php
            $args = array(
                'post_type' => 'post',
            'posts_per_page' => 10
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    ?>
                    <div class="col-md-4">
						<div class="blog-post ">
							<?php if (has_post_thumbnail()) : ?>
								<a href="<?php the_permalink(); ?>">
									<?php the_post_thumbnail('full'); ?>
								</a>
							<?php endif; ?>
							<div class="post-meta">
								<span class="post-date"><?php echo get_the_date(); ?></span>
								<span class="post-author">By <?php the_author(); ?></span>
							</div>
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						</div>
                    </div>
                    <?php
                endwhile;
            else :
                echo 'No posts found.';
            endif;
            ?>
        </div>
        <button id="load-more">Load More</button>
    </main>
</div>
<script>
    jQuery(document).ready(function($) {
var offset = 10; // Initial offset
var posts_per_page = 6; // Number of posts to load per click

$('#load-more').on('click', function() {
    $.ajax({
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        type: 'post',
        data: {
            action: 'load_more_posts',
            offset: offset,
            posts_per_page: posts_per_page
        },
        success: function(response) {
            $('#blog-posts').append(response);
            offset += posts_per_page;
        }
    });
});
});
</script>
<?php get_footer(); ?>