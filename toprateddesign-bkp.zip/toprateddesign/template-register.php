<?php
// Template Name: Register Company
if (is_user_logged_in()) {
    $user = wp_get_current_user();
    if (in_array('company', (array) $user->roles)) {
        wp_redirect(site_url() . '/company-profile/');
        exit;
    } else {
        wp_redirect(site_url());
        exit;
    }
}

get_header();

?>


<section class="company-profile-create">
    <div class="container">
        <div class="company-profile-create-inner">
            <div class="row align-items-center no-gutters">
                <div class="col-lg-6">
                    <div class="form-content">
                        <h2>Add Your Company</h2>
                        <p class="mb-4">Lorem ipsum dolor sit amet consectetur. Lacus sapien libero pretium ridiculus nisl. Eu feugiat ipsum scelerisque pellentesque. Sagittis quam euismod nullam justo diam.</p>

                        <form class="submit-form-using-ajax">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">First Name *</span>
                                            <input type="text" placeholder="First Name" name="first_name">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Last Name *</span>
                                            <input type="text" placeholder="Last Name" name="last_name">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Company Name</span>
                                            <input type="text" placeholder="Company Name" name="company_name">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Email *</span>
                                            <input type="email" placeholder="Email" name="email">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Website</span>
                                            <input type="text" placeholder="Website" name="website">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Password *</span>
                                            <input type="password" placeholder="Password" name="password">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Confirm Password *</span>
                                            <input type="password" placeholder="Confirm Password" name="confirm_password">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <input type="hidden" name="action" value="company_register">
                                    <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn btn-icon-pos-left">
                                        Register
                                        <span class="wd-btn-icon">
                                            <img width="30" height="30" src="https://topratedwebstg.wpengine.com/wp-content/uploads/2024/02/Icon.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="img-wrap">
                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/04/register-img.png" alt="Company Image" class="w-100">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php get_footer(); ?>