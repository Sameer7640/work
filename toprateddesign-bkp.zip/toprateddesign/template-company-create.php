<?php
// Template Name: Create Company

if (!is_user_logged_in()) {
    wp_redirect(site_url('/login'));
    exit;
}

get_header(); ?>


<style>

</style>

<div class="col-12">
    <section class="company-creation-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <nav class="company-nav-menu">
                        <ul>
                            <li class="company-menu-item">
                                <a href="#" data-step="1" class="active">
                                    Company Profile
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="2">
                                    Services
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="3">
                                    Locations
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="4">
                                    Industry Focus
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="5">
                                    Reviews
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="6">
                                    Portfolio
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="7">
                                    FAQs
                                </a>
                            </li>
                            <li class="company-menu-item">
                                <a href="#" data-step="8">
                                    Employee Profile
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-9">
                    <!-- Profile Completion -->
                    <div class="company-form-content">
                        <h4>Profile Completion</h4>
                        <div class="progress-bar">
                            <span class="progress-bar-fill" style="width: 10%"></span>
                        </div>
                    </div>

                    <div id="ajax-content">
                        <?php get_template_part('wp-backend/templates/company/company-create', 'step1'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="mfp-hide popup-review">
        <section class="mfp-with-anim dashboard-popup">
            <div class="row">
                <div class="col-md-12">
                    <div class="modal-body">
                        <h3 class="modal-title">Portfolio</h3>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">
                                <label class="image-file-selector mb-md-0   ">
                                    <input type="file" name="company_profile_image">
                                    <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/03/Image-1.jpg" alt="">
                                    <span class="label-text">
                                        Upload Logo *
                                    </span>
                                </label>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <span class="label-text">Title *</span>
                                    <input type="text" placeholder="Title" name="portfolio_title">
                                </div>
                                <div class="form-group">
                                    <span class="label-text">Portfolio URL *</span>
                                    <input type="text" placeholder="Portfolio URL" name="portfolio_url">
                                </div>
                                <div class="form-group">
                                    <span class="label-text">Project Description *</span>
                                    <textarea name="portfolio_description" cols="30" rows="4" placeholder="Description"></textarea>
                                </div>
                                <div class="text-right">
                                    <button class="btn btn-color-dark btn-style-default btn-style-round btn-size-default dark-btn mb-3">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <script type="text/javascript">
        jQuery(document).ready(function($) {

            jQuery(document).on('click', '.open-portfolio-add-modal', function(event) {
                event.preventDefault();

                jQuery(this).magnificPopup({
                    items: {
                        src: '.popup-review',
                        type: 'inline'
                    },
                    fixedContentPos: true,
                    callbacks: {
                        beforeOpen: function() {
                            jQuery('html').addClass('mfp-helper');
                        },
                        close: function() {
                            jQuery('html').removeClass('mfp-helper');
                        }
                    }
                }).magnificPopup('open');

            }); //click ends here
        });
    </script>
</div>

<?php get_footer(); ?>