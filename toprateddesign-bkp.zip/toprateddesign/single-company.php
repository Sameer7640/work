<?php
// Template Name: Companies
get_header();

$company_profile = json_decode(get_post_meta(get_the_ID(), 'company_profile', true));

$company_services = json_decode(get_post_meta(get_the_ID(), 'company_services', true));
$company_services = (array) $company_services;
arsort($company_services);

$company_sub_services = json_decode(get_post_meta(get_the_ID(), 'company_sub_services', true));
$company_sub_services = (array) $company_sub_services;

$business_address = json_decode(get_post_meta(get_the_ID(), 'business_address', true));

$industry_focus = json_decode(get_post_meta(get_the_ID(), 'industry_focus', true));
$industry_focus = (array) $industry_focus;
arsort($industry_focus);


global $wpdb;
$table_name = 'company_portfolios';
$company_id = get_the_ID();
$company_portfolios = $wpdb->get_results("SELECT * FROM $table_name WHERE company_id = $company_id");

$table_name = 'company_employees';
$company_employees = $wpdb->get_results("SELECT * FROM $table_name WHERE company_id = $company_id");

$table_name = 'company_faqs';
$company_faqs = $wpdb->get_results("SELECT * FROM $table_name WHERE company_id = $company_id");
?>
<style>
    .main-page-wrapper>.container {
        width: 100%;
        max-width: 100%;
        padding: 0px;
    }
</style>
<div class="col-12">
    <div class="header-clearfix"></div>
    <div class="col-12">
        <pre><?php print_r(get_post_meta(get_the_ID(), 'company_profile', true)); ?></pre>
        <pre><?php print_r(get_post_meta(get_the_ID(), 'company_services', true)); ?></pre>
        <pre><?php print_r(get_post_meta(get_the_ID(), 'company_sub_services', true)); ?></pre>
        <pre><?php print_r(get_post_meta(get_the_ID(), 'business_address', true)); ?></pre>
        <pre><?php print_r(get_post_meta(get_the_ID(), 'industry_focus', true)); ?></pre>
    </div>

    <section class="single-company-profile">
        <div class="container">
            <div class="breadcrumbs">
                <a href="#">Home</a>
                <a href="#">Top Website Designers</a>
                <span>
                    <?php the_title(); ?>
                </span>
            </div>

            <div class="portfolio-inner">
                <div class="row">
                    <div class="col-lg-3 col-md-4">
                        <div class="company-logo">
                            <a href="#" class="open-profile">
                                <?php
                                if (has_post_thumbnail()) {
                                    $featured_image = get_the_post_thumbnail_url(get_the_ID(), 'large');
                                } else {
                                    $featured_image = 'https://topratedwebdesign.com/wp-content/uploads/2024/02/eseospace-logo-300x193.png';
                                }
                                ?>
                                <img decoding="async" src="<?php echo $featured_image; ?>" alt="<?php the_title(); ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-8">
                        <div class="row justify-content-center">
                            <div class="col-md">
                                <div class="company-detail-wrapper">
                                    <div class="company-title">
                                        <h3>
                                            <?php the_title(); ?>
                                        </h3>
                                    </div>
                                    <a href="#" class="company-category">Top Rated Web Design & Development</a>
                                    <div class="company-rating">
                                        4.9 <small>(17 reviews)</small>
                                    </div>
                                    <div class="company-inner-texr">
                                        <?php echo $company_profile->about_company; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="company-contact-info">
                                    <div class="company-cta text-right">
                                        <div class="custom-btn-wrapper">
                                            <a href="<?php echo $company_profile->website; ?>" class="btn cstm-primary-btn cstm-primary-icon-btn" target="_blank">
                                                Visit Website
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="company-meta-information row justify-content-between">
                            <div class="col-auto">
                                <span>Headquarters</span>
                                <?php
                                $address = $business_address->business_address_line_1;
                                $address .= $business_address->business_address_line_2 ? ', ' . $business_address->business_address_line_2 : '';
                                $address .= $business_address->business_city ? ', ' . $business_address->business_city : '';
                                $address .= $business_address->business_state ? ', ' . $business_address->business_state : '';
                                $address .= $business_address->business_zip_code ? ', ' . $business_address->business_zip_code : '';
                                ?>
                                <p>
                                    <strong><?php echo $address; ?></strong>
                                </p>
                            </div>
                            <div class="col-auto">
                                <span>Phone Number</span>
                                <p>
                                    <strong>
                                        <?php echo $company_profile->phone_number; ?>
                                    </strong>
                                </p>
                            </div>
                            <div class="col-auto">
                                <span>Email</span>
                                <p>
                                    <strong>
                                        <?php echo $company_profile->email; ?>
                                    </strong>
                                </p>
                            </div>
                            <div class="col-auto">
                                <span>Website</span>
                                <p>
                                    <strong>
                                        <?php echo $company_profile->website; ?>
                                    </strong>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="single-company-nav">
                <ul>
                    <li><a href="#">Company Overview</a></li>
                    <li><a href="#">Portfolio</a></li>
                    <li><a href="#">Reviews</a></li>
                    <li><a href="#">Areas of Expertise</a></li>
                    <li><a href="#">Industries</a></li>
                    <li><a href="#">Employees</a></li>
                    <li><a href="#">FAQ's</a></li>
                </ul>
            </div>

            <div class="single-company-section">
                <h2><?php the_title(); ?> Overviewp</h2>
                <p>
                    <?php echo $company_profile->about_company; ?>
                </p>
                <div class="row company-overview-row">
                    <div class="col-md">
                        <div class="company-overview-boxes">
                            <div class="company-overview-box">
                                <div class="icon">
                                    <i class="fa fa-user"></i>
                                </div>
                                <div class="content">
                                    <h6>Employee Range</h6>
                                    <p>
                                        <?php echo $company_profile->employee_range; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="company-overview-box">
                                <div class="icon">
                                    <i class="fa fa-folder"></i>
                                </div>
                                <div class="content">
                                    <h6>Min. Project Amount</h6>
                                    <p>
                                        <?php echo $company_profile->min_project_amount; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="company-overview-box">
                                <div class="icon">
                                    <i class="fa fa-clock"></i>
                                </div>
                                <div class="content">
                                    <h6>Cost Per Hour</h6>
                                    <p>
                                        <?php echo $company_profile->cost_per_hour; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="company-overview-box">
                                <div class="icon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <div class="content">
                                    <h6>Year Founded</h6>
                                    <p>
                                        <?php echo $company_profile->year_found; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="company-social-icons">
                            <ul class="social-icons wd-social-icons icons-design-primary color-scheme-dark social-form-circle social-follow icons-size-default">
                                <?php if ($company_profile->facebook) : ?>
                                    <li>
                                        <a href="<?php echo $company_profile->facebook; ?>" class="wd-social-icon social-facebook">
                                            <span class="wd-icon"></span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if ($company_profile->linkedin) : ?>
                                    <li>
                                        <a href="<?php echo $company_profile->linkedin; ?>" class="wd-social-icon social-linkedin">
                                            <span class="wd-icon"></span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if ($company_profile->youtube) : ?>
                                    <li>
                                        <a href="<?php echo $company_profile->youtube; ?>" class="wd-social-icon social-youtube">
                                            <span class="wd-icon"></span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if ($company_profile->twitter) : ?>
                                    <li>
                                        <a href="<?php echo $company_profile->twitter; ?>" class="wd-social-icon social-twitter">
                                            <span class="wd-icon"></span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($company_profile) : ?>
                <div class="single-company-section">
                    <h2>Projects</h2>
                    <div class="company-portfolio row">
                        <?php foreach ($company_portfolios as $portfolio) : ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="portfolio-item">
                                    <div class="image-wrap">
                                        <img src="<?php echo $portfolio->image; ?>" alt="">
                                    </div>
                                    <div class="portfolio-text-wrap">
                                        <h4><?php echo $portfolio->name; ?></h4>
                                        <p><?php echo $portfolio->description; ?></p>
                                        <p class="font-medium">Estimated Timeline of Project: <?php echo $portfolio->budget; ?> Weeks</p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="single-company-section">
                <h2>Reviews</h2>
                <div class="company-reviews-section">
                    <div class="company-review-item">
                        <h3>Web Design and SEO</h3>
                        <p class="font-medium">Project Type: Web Design</p>
                        <p>I just want to express my deepest gratitude for all of your help. I can't tell you enough how much I LOVE the website. I think it's so beautiful, professional and elegant. I think it's one of the best therapist's website[s] on the market :) Thanks to Jeanette and [the] rest of the team for their creativity and neat work and Irina for her incredible knowledge about SEO and resources! You guys rock! (Verified via email)</p>
                        <div class="row company-review-author">
                            <div class="col-auto">
                                <div class="img-wrap">
                                    <img src="https://topratedwebdesign.com/wp-content/uploads/2024/05/Ellipse-57-1.png">
                                </div>
                            </div>
                            <div class="col">
                                <h4>Muriell Carlisle, LMHC, RAS, C.H.T.</h4>
                                <p><em>Owner at Counseling Oregon, LLC</em></p>
                            </div>
                        </div>
                        <p class="font-medium">Review Date: 23 August, 2023</p>
                    </div>
                </div>
            </div>

            <div class="single-company-section">
                <h2>Areas of Expertise</h2>
                <br>
                <h4>Key Services</h4>
                <hr>
                <ul class="areas-of-expertise-nav">
                    <?php
                    $company_services = array_slice($company_services, 0, 6);
                    foreach ($company_services as $key => $value) : ?>
                        <li>
                            <a href="javascript:void(0)"><?php echo ucwords(str_replace('_', ' ', $key)); ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <h4>Company Sub Services</h4>
                <hr>
                <div class="company-sub-services-row row">
                    <?php
                    foreach ($company_sub_services as $service_label => $service) : ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="company-sub-service-item">
                                <h5><?php echo ucwords(str_replace('_', ' ', $service_label)); ?></h5>
                                <hr>
                                <?php if (is_array($service)) : ?>
                                    <ul>
                                        <?php foreach ($service as $sub_service) : ?>
                                            <li>
                                                <?php echo ucwords(str_replace('_', ' ', $sub_service)); ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <!-- <div class="col-md-6 col-lg-3">
                        <div class="company-sub-service-item">
                            <h5>Mobile App Development</h5>
                            <hr>
                            <ul>
                                <li>App Design</li>
                                <li>React Native</li>
                                <li>Android App</li>
                                <li>Flutter</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="company-sub-service-item">
                            <h5>Framework and CMS</h5>
                            <hr>
                            <ul>
                                <li>Laravel</li>
                                <li>WordPress</li>
                                <li>Front End Developers</li>
                                <li>WordPress Web Design</li>
                                <li>Other Frameworks and CMS</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="company-sub-service-item">
                            <h5>Programming and Scripting</h5>
                            <hr>
                            <ul>
                                <li>NodeJS</li>
                                <li>SQL</li>
                                <li>React JS</li>
                                <li>PHP</li>
                                <li>JavaScript</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="company-sub-service-item">
                            <h5>Web and Software Development</h5>
                            <hr>
                            <ul>
                                <li>Web Development</li>
                                <li>Web Design</li>
                                <li>Progressive Web App (PWA)</li>
                            </ul>
                        </div>
                    </div> -->
                </div>
            </div>

            <div class="single-company-section">
                <h2>Industries</h2>
                <ul class="industries-section-nav">
                    <?php
                    $industry_focus = array_slice($industry_focus, 0, 8);
                    foreach ($industry_focus as $key => $value) : ?>
                        <li>
                            <a href="javascript:void(0)"><?php echo ucwords(str_replace('_', ' ', $key)); ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <?php if ($company_employees) : ?>
                <div class="single-company-section">
                    <h2>eSEOspace Employees</h2>
                    <div class="company-employees-row row">
                        <?php foreach ($company_employees as $employee) : ?>
                            <div class="col-lg-6">
                                <div class="employee-item">
                                    <div class="row employee-info-row align-items-center">
                                        <div class="col-auto">
                                            <div class="img-wrap">
                                                <img src="<?php echo $employee->image; ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <h4><?php echo $employee->name; ?></h4>
                                            <p><em><?php echo $employee->job_title; ?></em></p>
                                        </div>
                                    </div>
                                    <p class="employee-bio"><?php echo $employee->about; ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($company_faqs) : ?>
                <div class="single-company-section">
                    <h2>FAQs</h2>
                    <div class="company-faqs-row">
                        <?php foreach ($company_faqs as $faq) : ?>
                            <div class="faq-item">
                                <h4><?php echo $faq->question; ?></h4>
                                <p style="color: #4F4F4F;"><?php echo $faq->answer; ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- <div class="custom-btn-wrapper">
                    <a href="https://www.eseospace.com/" class="btn cstm-primary-btn cstm-primary-icon-btn" target="_blank">View All FAQs</a>
                </div> -->
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php get_footer(); ?>