<?php
// Template Name: Forgot Password
if (is_user_logged_in()) {
    $user = wp_get_current_user();
    if (in_array('company', (array) $user->roles)) {
        wp_redirect(site_url() . '/company-profile/');
        exit;
    } else {
        wp_redirect(site_url());
        exit;
    }
}

get_header();
?>

<section class="company-profile-login">
    <div class="container">
        <div class="company-profile-login-inner">
            <div class="row align-items-center no-gutters">
                <div class="col-lg-6">
                    <div class="form-content">
                        <h2>Forgot Password</h2>
                        <p class="mb-4">Enter your registered Email ID to find your account.</p>

                        <form class="submit-form-using-ajax">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Email *</span>
                                            <input type="email" placeholder="Email" name="email">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 text-lg-right">
                                    <a href="<?php echo site_url('login'); ?>" class="forgot-password-link d-inline-block mb-4">Go back</a>
                                </div>
                                <div class="col-12">
                                    <input type="hidden" name="action" value="forgot_password">
                                    <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn btn-icon-pos-left">
                                        Submit
                                        <span class="wd-btn-icon">
                                            <img width="30" height="30" src="https://topratedwebstg.wpengine.com/wp-content/uploads/2024/02/Icon.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                        </span>
                                    </button>
                                    <a href="<?php echo site_url(); ?>/register/" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn btn-icon-pos-left ml-3">
                                        Register
                                        <span class="wd-btn-icon">
                                            <img width="30" height="30" src="https://topratedwebstg.wpengine.com/wp-content/uploads/2024/03/Arrow.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="img-wrap">
                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/04/register-img.png" alt="Company Image" class="w-100">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>