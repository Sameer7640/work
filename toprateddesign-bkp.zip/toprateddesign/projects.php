<?php
// Template Name: Projects

get_header();
?>

<style>
    #project-page-title {
        padding: 90px 0 !important;
    }

    #project-page-title .breadcrumb-txt {
        color: #1E1E1E;
        font-family: 'Inter' !important;
        font-weight: 600 !important;
        font-size: 16px;
    }

    #project-page-title .breadcrumb-txt>span {
        opacity: 0.5;
    }

    #project-page-title .page-titlee {
        font-family: 'Inter' !important;
        font-weight: 700 !important;
        text-transform: capitalize !important;
        font-size: 55px !important;
        line-height: 65px !important;
        color: black;
        margin: 0;
        letter-spacing: -2px !important;
    }

    .projects-content {
        display: flex;
        display: flex;
        flex-wrap: wrap;
    }

    .projects-content .project-item {
        flex: 1 1 50%;
        flex: 0 1 50%;
        padding: 10px;
    }

    .projects-content .project-item img {
        border-radius: 4px;
    }

    .br-mb {
        margin-bottom: 20px;
    }

    .project-search-wrapper .project-search-input {
        padding-left: 3rem !important;
        color: #000;
        border: 0px !important;
        height: auto !important;
        padding: 14px;
    }

    .project-search-wrapper .project-search-input::placeholder {
        color: #999999;
    }

    .project-search-wrapper .br-search-icon {
        position: absolute;
        z-index: 2;
        display: block;
        width: 2.375rem;
        height: 3rem;
        line-height: 3.2rem;
        text-align: center;
        pointer-events: none;
        color: #000000;
    }

    .project-search-wrapper .fa-search.br-search-icon:before {
        font-size: 18px;
    }

    .project-search-wrapper {
        border: 2px solid #000000;
        border-radius: 8px;
    }

    .project-sort-wrapper select.project-sort {
        background-image: url(https://topratedwebdesign.com/wp-content/uploads/2024/05/svg-edited.svg);
        padding: 12px 20px;
        height: auto;
        color: #000;
        font-family: Inter;
        font-size: 14px;
        font-weight: 400;
        border: 2px solid #000000;
        border-radius: 8px;
        background-position: right 18px top 50%;
    }

    .project-category-list {
        list-style: none;
        padding: 0;
        margin-top: 20px;
    }

    .project-category-list li [type="radio"]:checked,
    .project-category-list li [type="radio"]:not(:checked) {
        position: absolute;
        left: -9999px;
    }

    .project-category-list li [type="radio"]:checked+label,
    .project-category-list li [type="radio"]:not(:checked)+label {
        position: relative;
        padding-left: 28px;
        cursor: pointer;
    }

    .project-category-list li [type="radio"]:checked+label:before,
    .project-category-list li [type="radio"]:not(:checked)+label:before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 20px;
        height: 20px;
        border: 2px solid #000;
        border-radius: 100%;
        background: #fff;
    }

    .project-category-list li [type="radio"]:checked+label:after,
    .project-category-list li [type="radio"]:not(:checked)+label:after {
        content: '';
        width: 20px;
        height: 20px;
        background: #6C2BD9;
        position: absolute;
        top: 0px;
        left: 0px;
        border-radius: 100%;
        -webkit-transition: all 0.2s ease;
        transition: all 0.2s ease;
    }

    .project-category-list li [type="radio"]:not(:checked)+label:after {
        opacity: 0;
        -webkit-transform: scale(0);
        transform: scale(0);
    }

    .project-category-list li [type="radio"]:checked+label:after {
        opacity: 1;
        -webkit-transform: scale(1);
        transform: scale(1);
    }

    .project-category-list li [type="radio"]:checked+label:before {
        transition: 0.3s ease-in-out;
        border: 2px solid #E3E2FF;
    }

    .project-category-list li label {
        font-family: 'Inter';
        font-size: 16px;
        font-weight: 400;
        line-height: 16.8px;
        text-align: left;
        color: #000;
    }

    .project-category-list li [type="radio"]:checked+label {
        font-weight: 700;
    }

    .clear-filter-wrapper {
        margin-top: 50px;
    }

    .clear-filter-wrapper .clear-filter-btn {
        width: 100%;
        padding: 13px 25px;
        border-radius: 99px;
        border: 1px solid #000000 !important;
        background: transparent !important;
        font-family: 'Inter';
        font-size: 16px;
        font-weight: 600;
        letter-spacing: -0.36px;
        text-align: center;
        color: #000 !important;
        text-transform: capitalize;
        outline: none;
    }

    .project-filter-by {
        font-family: Inter;
        font-size: 14px;
        font-weight: 600;
        letter-spacing: -0.36px;
        color: #000;
    }

    @media (max-width: 1440px) {
        #custom-blog-page {
            padding-left: 4%;
            padding-right: 4%;
        }

        #project-page-title .page-titlee {
            font-size: 50px !important;
            line-height: 60px !important;
        }
    }

    @media (max-width: 1024px) {
        #project-page-title .page-titlee {
            font-size: 40px !important;
            line-height: 50px !important;
        }

        #project-page-title {
            padding: 60px 0 !important;
        }

        #project-page-title .breadcrumb-txt {
            font-size: 14px !important;
            line-height: 24px !important;
        }
    }

    @media (max-width: 820px) {
        #project-page-title .page-titlee {
            font-size: 35px !important;
            line-height: 45px !important;
        }
    }

    @media (max-width: 480px) {
        #project-page-title {
            padding: 40px 0 !important;
        }

        #project-page-title .page-titlee {
            font-size: 28px !important;
            line-height: 38px !important;
        }

        #project-page-title .breadcrumb-txt {
            margin-bottom: 5px;
        }
    }

    @media (max-width: 414px) {
        #project-page-title .page-titlee {
            font-size: 26px !important;
            line-height: 36px !important;
        }
    }
</style>

<main id="main" class="site-main">

    <div id="project-page-title">
        <p class="breadcrumb-txt"><span style="color: #1E1E1E;"><a style="color: #1E1E1E;" href="https://topratedwebdesign.com/">Home</a> &gt; </span>Projects</p>
        <h1 class="page-titlee">Discover Our Diverse Portfolio: <br><span style="color: #30D4DE;">Explore a Showcase of Projects and Designs</span></h1>
    </div>

    <div id="project-main-wrapper" class="row">
        <div class="col-md-3">
            <div class="project-search-wrapper br-mb">
                <span class="fa fa-search br-search-icon"></span>
                <input type="text" class="project-search-input" placeholder="Search posts, keywords, authors...">
            </div>
            <div class="project-sort-wrapper br-mb">
                <select class="project-sort">
                    <option value="updated-new"><b>Sort by: </b> Updated (New - Old)</option>
                    <option value="updated-old"><b>Sort by: </b> Updated (Old - New)</option>
                    <option value="alphabetical-a"><b>Sort by: </b> Alphabetical (A - Z)</option>
                    <option value="alphabetical-z"><b>Sort by: </b> Alphabetical (Z - A)</option>
                </select>
            </div>
            <div class="project-filter-wrapper br-mb">
                <span class="project-filter-by">Filter By Category:</span>
                <?php
                $terms = get_terms(array(
                    'taxonomy' => 'project-cat',
                    'hide_empty' => false,
                ));
                ?>

                <ul class="project-category-list">
                    <?php foreach ($terms as $term) : ?>
                        <li class="br-mb">
                            <input type="radio" name="category" id="<?php echo esc_attr($term->slug); ?>">
                            <label for="<?php echo esc_attr($term->slug); ?>">
                                <?php echo esc_html($term->name); ?>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>

            </div>
            <div class="clear-filter-wrapper">
                <button class="clear-filter-btn">
                    Clear Filters
                </button>
            </div>
        </div>
        <div class="col-md-9">
            <div class="projects-content">
                <?php
                $args = array(
                    'post_type' => 'portfolio',
                    'post_status' => 'publish',
                    'posts_per_page' => -1
                );

                $query = new WP_Query($args);

                if ($query->have_posts()) :
                    while ($query->have_posts()) : $query->the_post();
                ?>
                        <div class="project-item">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php
                                $thumbnail_id = get_post_thumbnail_id();
                                $thumbnail = wp_get_attachment_image($thumbnail_id, 'full', false, array('class' => 'img-style'));
                                echo $thumbnail;
                                ?>
                            <?php endif; ?>
                        </div>
                <?php
                    endwhile;
                else :
                    echo 'No posts found.';
                endif;

                ?>
            </div>

        </div>
    </div>
</main>
<?php
get_footer();
?>