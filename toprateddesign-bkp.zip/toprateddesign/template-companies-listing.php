<?php
// Template Name: Companies
get_header(); ?>

<style>
    .main-page-wrapper>.container {
        width: 100%;
        max-width: 100%;
        padding: 0px;
    }
</style>
<div class="col-12">
    <div class="header-clearfix"></div>
    <section class="companies-listing-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <div class="companies-listing-header-box">
                        <div class="breadcrumbs">
                            <a href="<?php echo site_url(); ?>">Home</a>
                            <span>Top Website Designers</span>
                        </div>
                        <h2>Top Website Designers</h2>
                        <div class="row">
                            <div class="col-md-auto">
                                <div class="star-ratings">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                            <div class="col-md">
                                <p class="rating-text"><strong>Digital Agencies have a 4.5 avg. rating from 1,644 verified reviews</strong></p>
                            </div>
                        </div>
                        <p>Looking for a reliable digital agency to grow your online presence and revenue? We ranked the top-rated full-service digital agencies by portfolio, reviews, expertise, awards, and more. Filter the list based on location, price, etc., and find the matching team that fits your budget and requirements.</p>
                        <div class="row align-items-center">
                            <div class="col-md">
                                <a href="#" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn btn-icon-pos-left">
                                    Digital Agency Hiring Guide
                                    <span class="wd-btn-icon">
                                        <img width="30" height="30" src="<?php echo site_url(); ?>/wp-content/uploads/2024/02/Icon.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                    </span>
                                </a>
                            </div>
                            <div class="col-md-auto">
                                <p class="ranking-text">Ranking Updated: December 21, 2023</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="trophy-box">
                        <div class="img-wrap">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/05/Trophy-1.png">
                        </div>
                        <h4>
                            Top Rated Website designers
                        </h4>
                        <div class="star-ratings">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="companies-listing-filters">
        <div class="container">
            <h2>List of the Top Website Designers</h2>
            <p>Ranking Updated: December 21, 2023</p>
            <form class="submit-form-using-ajax companies-listing-filter-form">
                <div class="row">
                    <div class="col-md">
                        <div class="form-group">
                            <input type="text" placeholder="Search by State" name="state">
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-group">
                            <input type="text" placeholder="Search by City" name="city">
                        </div>
                    </div>
                    <div class="col-md-auto">
                        <input type="hidden" name="action" value="search_companies_by_city_or_state">
                        <button class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn btn-icon-pos-left">
                            Search
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <div class="companies-listing-grid">
        <div class="container">
            <?php
            $args = array(
                'post_type' => 'company',
                'posts_per_page' => -1,
                'orderby' => 'title',
                'order' => 'DESC',
            );

            $query = new WP_Query($args);
            ?>

            <?php if ($query->have_posts()) : ?>
                <div class="row">
                    <?php while ($query->have_posts()) : $query->the_post(); ?>
                        <?php include get_stylesheet_directory() . '/wp-backend/templates/template-parts/company-grid-item.php'; ?>
                    <?php endwhile; ?>
                </div>
            <?php else : ?>
                <div class="row">
                    <div class="col-12">
                        <h4>No companies found!</h4>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>