<?php
// Template Name: Login Company
if (is_user_logged_in()) {
    $user = wp_get_current_user();
    if (in_array('company', (array) $user->roles)) {
        wp_redirect(site_url() . '/company-profile/');
        exit;
    } else {
        wp_redirect(site_url());
        exit;
    }
}

get_header();

$account_created = false;
$link_expired = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    global $wpdb;

    $query = $wpdb->prepare("SELECT * FROM company_temp_users WHERE token = %s", $token);

    $result = $wpdb->get_row($query);

    if ($result) {
        $first_name = $result->first_name;
        $last_name = $result->last_name;
        $company_name = $result->company_name;
        $email = $result->email;
        $website = $result->website;
        $password = $result->password;
        $token = $result->token;

        $user_id = wp_create_user($email, $password, $email);

        if (is_wp_error($user_id)) {
            $error_string = $user_id->get_error_message();
        } else {
            update_user_meta($user_id, 'first_name', $first_name);
            update_user_meta($user_id, 'last_name', $last_name);
            update_user_meta($user_id, 'company_name', $company_name);
            update_user_meta($user_id, 'website', $website);
            update_user_meta($user_id, 'company_profile_completed', 0);

            $user = new WP_User($user_id);
            $user->set_role('company');

            // create a company post
            $company_post = array(
                'post_title'    => $company_name,
                'post_status'   => 'publish',
                'post_author'   => $user_id,
                'post_type'     => 'company'
            );

            $company_id = wp_insert_post($company_post);

            // save user in company post
            update_post_meta($company_id, 'user_id', $user_id);

            // save company id in user meta
            update_user_meta($user_id, 'company_id', $company_id);

            $wpdb->delete('company_temp_users', array('token' => $token));

            $account_created = true;
        }
    } else {
        $link_expired = true;
    }
}

?>

<section class="company-profile-login">
    <div class="container">
        <div class="company-profile-login-inner">
            <div class="row align-items-center no-gutters">
                <div class="col-lg-6">
                    <div class="form-content">
                        <h2>Login Now</h2>
                        <p class="mb-4">Enter your registered email ID and Password to access your account.</p>

                        <form class="submit-form-using-ajax">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Email *</span>
                                            <input type="email" placeholder="Email" name="email">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label>
                                            <span class="label-text">Password *</span>
                                            <input type="password" placeholder="Password" name="password">
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 text-lg-right">
                                    <a href="<?php echo site_url('forgot-password'); ?>" class="forgot-password-link d-inline-block mb-4">Forgot Password?</a>
                                </div>
                                <div class="col-12">
                                    <input type="hidden" name="action" value="company_login">
                                    <button type="submit" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default primary-btn btn-icon-pos-left">
                                        Login
                                        <span class="wd-btn-icon">
                                            <img width="30" height="30" src="https://topratedwebstg.wpengine.com/wp-content/uploads/2024/02/Icon.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                        </span>
                                    </button>
                                    <a href="<?php echo site_url(); ?>/register/" class="btn btn-color-primary btn-style-default btn-style-round btn-size-default tertiary-btn btn-icon-pos-left ml-3">
                                        Register
                                        <span class="wd-btn-icon">
                                            <img width="30" height="30" src="https://topratedwebstg.wpengine.com/wp-content/uploads/2024/03/Arrow.svg" class="attachment-medium size-medium" alt="" decoding="async">
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="img-wrap">
                        <img src="<?php echo site_url(); ?>/wp-content/uploads/2024/04/register-img.png" alt="Company Image" class="w-100">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SHOW MESSAGE FOR ACCOUNT CREATION -->
<?php if ($account_created) : ?>
    <script>
        jQuery(document).ready(function() {
            Swal.fire({
                title: 'Email Verified',
                text: 'Your account has been verified. You can now login to your account.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        })
    </script>
<?php endif; ?>

<!-- SHOW MESSAGE OF LINK EXPIRY -->
<?php if ($link_expired) : ?>
    <script>
        jQuery(document).ready(function() {
            Swal.fire({
                title: 'Account already verified',
                text: 'Your account has already been verified.',
                icon: 'success',
                confirmButtonText: 'OK'
            });
        })
    </script>
<?php endif; ?>

<?php get_footer(); ?>