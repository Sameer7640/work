<?php

include_once 'wp-backend/wp-backend.php';

/**
 * Enqueue script and styles for child theme
 */
function woodmart_child_enqueue_styles()
{
    // wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'woodmart-style' ), woodmart_get_theme_info( 'Version' ) );
    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array('woodmart-style'), rand(111, 9999));
}
add_action('wp_enqueue_scripts', 'woodmart_child_enqueue_styles', 10010);








add_action('wp_ajax_load_more_posts', 'load_more_posts');
add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts');

function load_more_posts()
{
    $offset = $_POST['offset'];
    $posts_per_page = $_POST['posts_per_page'];

    $args = array(
        'post_type' => 'post',
        'posts_per_page' => $posts_per_page,
        'offset' => $offset
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();
            // Display your post content here
            ?>
            <div class="col-md-4">
				<div class="blog-post ">
					<?php if (has_post_thumbnail()) : ?>
					<a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail('full'); ?>
					</a>
					<?php endif; ?>
					<div class="post-meta">
						<span class="post-date"><?php echo get_the_date(); ?></span>
						<span class="post-author">By <?php the_author(); ?></span>
					</div>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				</div>
			</div>
            <?php
        endwhile;
    endif;

    wp_die();
}
