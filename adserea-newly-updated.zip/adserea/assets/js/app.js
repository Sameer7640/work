$('.packages-tabs .tabs-content .tab:not(:nth-child(1))').hide();
$('.packages-tabs .tabs-content .tab:not(:nth-child(1))').css({
	opacity: '0',
	transform: 'translateY(30px)'
});
$('.packages-tabs .tabs-navigation li a').click(function(e) {
	e.preventDefault();
	$(this).parent().addClass('active');
	$('.packages-tabs .tabs-navigation li a').not(this).parent().removeClass('active');
	var indexPos = $(this).parent().index();
	var totalElements = $('.packages-tabs .tabs-content').children().length;
	var contentToggler = indexPos + 1;
	$('.packages-tabs .tabs-content .tab:nth-child('+contentToggler+')').show();
	$('.packages-tabs .tabs-content .tab:nth-child('+contentToggler+')').css({
		opacity: '1',
		transform: 'translateY(0)'
	});
	$('.packages-tabs .tabs-content .tab:not(:nth-child('+contentToggler+'))').hide();
	$('.packages-tabs .tabs-content .tab:not(:nth-child('+contentToggler+'))').css({
		opacity: '0',
		transform: 'translateY(30px)'
	});
});

$('.toggle .toggle-body').hide();
$('.toggle .toggle-trigger a').click(function(e) {
	e.preventDefault();
	$(this).parent().parent().toggleClass('active');
	$(this).parent().parent().find('.toggle-body').slideToggle();
});


$('.packages-carousel').owlCarousel({
    loop:false,
    margin:0,
    nav:false,
	dot:true,
    responsive:{
        0:{
            items:1
        },
        800:{
            items:2
        },
        1200:{
            items:3
        }
    }
})
$('.costing-carousel').owlCarousel({
    loop:false,
    margin:0,
    nav:false,
	dot:true,
    items:1
})