<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetSMSNotificationsHistoryCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class GetSMSNotificationsHistoryCommand extends Command
{

}
