<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateSMSNotificationHistoryCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class UpdateSMSNotificationHistoryCommand extends Command
{

}
