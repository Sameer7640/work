<?php

namespace AmeliaBooking\Application\Commands\User;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetUserDeleteEffectCommand
 *
 * @package AmeliaBooking\Application\Commands\User
 */
class GetUserDeleteEffectCommand extends Command
{

}
