<?php

namespace AmeliaBooking\Application\Commands\User;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeleteUserCommand
 *
 * @package AmeliaBooking\Application\Commands\User
 */
class DeleteUserCommand extends Command
{

}
