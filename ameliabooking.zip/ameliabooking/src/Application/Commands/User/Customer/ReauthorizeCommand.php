<?php

namespace AmeliaBooking\Application\Commands\User\Customer;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class ReauthorizeCommand
 *
 * @package AmeliaBooking\Application\Commands\User\Customer
 */
class ReauthorizeCommand extends Command
{
}
