<?php

namespace AmeliaBooking\Application\Commands\User;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetWPUsersCommand
 *
 * @package AmeliaBooking\Application\Commands\User
 */
class GetWPUsersCommand extends Command
{

}
