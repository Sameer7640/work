<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetEventsCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class GetEventsCommand extends Command
{

}
