<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateEventCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class UpdateEventCommand extends Command
{

}
