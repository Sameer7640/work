<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetEventDeleteEffectCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class GetEventDeleteEffectCommand extends Command
{

}
