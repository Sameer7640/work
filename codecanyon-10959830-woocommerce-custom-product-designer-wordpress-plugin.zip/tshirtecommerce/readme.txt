=== WooCommerce - T-Shirt eCommerce - T-Shirt Designer ===
Contributors: T-Shirt eCommerce
Tags: ecommerce, e-commerce, commerce, woocommerce, T-Shirt eCommerce, t-shirt ecommerce, t-shirt designer
Requires at least: 3.1
Tested up to: 3.9.1
Stable tag: 1.0.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

T-Shirt eCommerce - woocommerce help you build a full website powerful with custom product and sale online.

== Description ==

T-shirt eCommerce tools is online solution of customizing various type of products like – T-shirt, Laptop Skin, Cap, Mobile phone / iphone / ipad skin, Bags, Mugs…

== Installation ==

1. Upload this plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Build product
4. Export data
5. Import data
6. Setting

== ShortCode ==

Copy this shortcode to page you want set menu "design online"
[tshirtecommerce id="product_id"]


== Screenshots ==

== Changelog ==

= 1.1.0 =
* Initial release
